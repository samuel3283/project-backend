import {PrimengModule} from './primeng/primeng.module';

import {NgModule} from '@angular/core';

import {FormsModule} from '@angular/forms';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {AppRoutes} from './app.routes';

import {AppComponent} from './app.component';

import {LoginComponent} from './login/login.component';

import {NgxSpinnerModule} from 'ngx-spinner';
import {PagesModule} from './pages/pages.module';
import {SharedModule} from './shared/shared.module';

import {BlockUIModule} from 'ng-block-ui';

import {MenubarModule} from 'primeng/menubar';

import {InputSwitchModule} from 'primeng/inputswitch';

import {AutoCompleteModule} from 'primeng/autocomplete';
import {DropdownModule} from 'primeng/dropdown';
import {InputNumberModule} from 'primeng/inputnumber';
import {SplitButtonModule} from 'primeng/splitbutton';

import {BasicAuthHtppInterceptorService} from '../app/service/BasicAuthHtppInterceptorService';
import {NuevosComponent} from './panel-administrativo/nuevos/nuevos.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {PanelFiltrosComponent} from './panel-administrativo/panel-filtros/panel-filtros.component';

import {PaginatorComponent} from './panel-administrativo/paginator/paginator.component';
import {PaginatorTodosComponent} from './panel-administrativo/todos/paginator-todos/paginator-todos.component';
import {DataTableModule} from '@pascalhonegger/ng-datatable';

import {InicioComponent} from './panel-administrativo/inicio/inicio.component';
import {EditarRecomendadoComponent} from './panel-administrativo/editar-recomendado/editar-recomendado.component';
import {TodosComponent} from './panel-administrativo/todos/todos.component';
import {EvaluacionComponent} from './panel-administrativo/evaluacion/evaluacion.component';
import {MenuRutasComponent} from './panel-administrativo/menu-rutas/menu-rutas.component';
import {ContratadosComponent} from './panel-administrativo/contratados/contratados.component';
import {ReclutadoresComponent} from './panel-administrativo/reclutadores/reclutadores.component';
import {InputMaskModule} from 'primeng/inputmask';

@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        AppRoutes,
        HttpClientModule,
        BrowserAnimationsModule,
        NgxSpinnerModule,
        PagesModule,
        SharedModule,
        BlockUIModule.forRoot(),
        MenubarModule,
        InputSwitchModule,
        NgbModule,
        DataTableModule,
        PrimengModule,
        DropdownModule,
        AutoCompleteModule,
        InputNumberModule,
        SplitButtonModule,
        InputMaskModule,
    ],
    declarations: [
        AppComponent,
        LoginComponent,
        InicioComponent,
        NuevosComponent,
        PanelFiltrosComponent,
        PaginatorComponent,
        EditarRecomendadoComponent,
        PaginatorTodosComponent,
        TodosComponent,
        EvaluacionComponent,
        MenuRutasComponent,
        ContratadosComponent,
        ReclutadoresComponent,
    ],
    providers: [
        {
            provide: HTTP_INTERCEPTORS,
            useClass: BasicAuthHtppInterceptorService,
            multi: true
        }

    ],
    //  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],

    bootstrap: [AppComponent]
})
export class AppModule {
}
