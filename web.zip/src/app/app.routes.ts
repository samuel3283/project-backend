import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { TodosComponent } from './panel-administrativo/todos/todos.component';
import { NuevosComponent } from './panel-administrativo/nuevos/nuevos.component';
import { InicioComponent } from './panel-administrativo/inicio/inicio.component';
import { EditarRecomendadoComponent } from './panel-administrativo/editar-recomendado/editar-recomendado.component';
import {EvaluacionComponent} from './panel-administrativo/evaluacion/evaluacion.component';
import {ContratadosComponent} from './panel-administrativo/contratados/contratados.component';
import {ReclutadoresComponent} from './panel-administrativo/reclutadores/reclutadores.component';


const pagesRoutes: Routes = [
    {
        path: 'admin',
        component: InicioComponent,
        children: [
            { path: 'login', component: LoginComponent },
            { path: 'panel/editar/recomendado', component: EditarRecomendadoComponent },
            { path: 'panel/todos', component: TodosComponent },
            { path: 'panel/todos/page/:page', component: TodosComponent },
            { path: 'panel/nuevos', component: NuevosComponent },
            { path: 'panel/nuevos/page/:page', component: NuevosComponent },
            { path: 'panel/evaluacion', component: EvaluacionComponent },
            { path: 'panel/evaluacion/page/:page', component: EvaluacionComponent },
            { path: 'panel/contratados', component: ContratadosComponent },
            { path: 'panel/contratados/page/:page', component: ContratadosComponent },
            { path: 'panel/reclutadores', component: ReclutadoresComponent },
            { path: 'panel/reclutadores/page/:page', component: ReclutadoresComponent }

        ]
    }
];

export const AppRoutes: ModuleWithProviders = RouterModule.forRoot(pagesRoutes, { useHash: false });
