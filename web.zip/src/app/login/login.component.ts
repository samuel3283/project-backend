import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';

import {BlockUI, NgBlockUI} from 'ng-block-ui';

import {LoginService} from 'src/app/service/loginService';

import {ConstantesUtil} from '../util/constantesUtil';

import {environment} from '../../environments/environment';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

    @BlockUI() blockUI: NgBlockUI;

    constructor(private router: Router, private loginService: LoginService) {
    }

    ngOnInit() {
        this.obtenerTokenURL();
    }

    login(): void {
        this.router.navigate([ConstantesUtil.talento]);
    }

    obtenerTokenURL() {
        sessionStorage.clear();
        const url = window.location + '';
        const parametrosUrl = url.split('token=');
        console.log('token portal: ' + parametrosUrl[1]);

        if (parametrosUrl[1] === null || parametrosUrl[1] === '' || parametrosUrl[1] === undefined) {
            location.href = environment.urlPortal;
        }

        const token = parametrosUrl[1];
        console.log('tokentokentoken: ' + token);
        this.loginService.loginPortal(token).subscribe(data => {

            if (data.codMsj === ConstantesUtil.codMsjError) {
                location.href = environment.urlDefaultTalento;
                return;
            }

            const tokenStr = 'Bearer ' + data.token;
            sessionStorage.setItem('token', tokenStr);
            sessionStorage.setItem('idPersonal', data.idPersonal);
            sessionStorage.setItem('email', data.email);
            sessionStorage.setItem('nombresCompletos', data.nombresCompletos);
            sessionStorage.setItem('rolUsuario', data.rolUsuario);
            this.router.navigate([ConstantesUtil.paginaAdministrativo]);

            this.blockUI.stop();
        });

    }

}
