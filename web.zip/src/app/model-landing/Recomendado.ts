export class Recomendado {
    id: number;
    idDistrito: number;
    idProvincia: number;
    idDepartamento: number;
    nombreUbigeo: string;
    estado: string;
    fechaActualizacion: null;
    fechaCreacion: string;
    nombre: string;
    apellido: string;
    numeroDocumento: string;
    idRelacion: number;
    telefono: string;
    idPuesto: number;
    cv: string;
}
