export class Colaborador {
    id: string;
    nombres: string;
    apellidos: string;
    cargo: string;
    marca: string;
    mensaje: string;
    telefono: string;
    documento: string;
    email: string;
    local: string;
    cv: string;
}
