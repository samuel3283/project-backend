import {Respuesta} from './respuesta';

export class Pregunta {
    id: string;
    enunciado: string;
    idRespuesta: string;
    idPuesto: string;
    idTipoPregunta: string;
    opcionRespuestas: Respuesta[];
    /*Respuesta Radio Button */
    respuestaEnunciado: string;
    /*Respuesta AutoComplete */
    respuestaAutocomplete: any;
    respuestaAutocomplete2 = '0';
}
