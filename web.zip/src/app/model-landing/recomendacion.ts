export class Recomendacion {
    id: string;
    cv: string;
    dniRecomendado: string;
    idRecomendado: string;
    idPuesto: string;
    idColaborador: string;
    extensionDelArchivo: string;
}
