import {RespuestaAdmin} from '../panel-administrativo/models/RespuestaAdmin';

export class Referente {
    evento: any;
    nombres: string;
    apellidos: string;
    dni: string;
    nombreDistrito: string;
    nombreUbigeo: string;
    telefono: string;
    idDistrito: string;
    idDepartamento: string;
    idProvincia: string;
    idTipoParametro: string;
    idPuesto: string;
    idCarrera: string;
    nombreDepartamento: string;
    nombreProvincia: string;
    concatUbigeo: string;
    estado: string;
    idRecomendado: any;
    idColaborador:any;

    /*Datos Extra*/
    idHorario: string;
    zonaPreferencia: string;
    observacionesPuesto: string;
    observacionesContrato: string;
    listaRespuesta: RespuestaAdmin[];
    idRecomendacion: string;
    cvRecomendado: string;
    idLocalContrato: any;
    dateContrato: Date;
    idMotivo:string;
    numeroTarjeta:any;

}
