export class Respuesta {
    id: string;
    enunciado: string;
    idPregunta: string;
    idTipoPregunta: string;
}
