export class Organizaciones {

    id: number;
    nombre: string;
    estado: string;

}
