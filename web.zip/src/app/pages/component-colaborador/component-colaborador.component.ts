import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ConstantesUtil} from 'src/app/util/constantesUtil';
import {Location} from '@angular/common';
import {ColaboradorService} from 'src/app/service-landing/ColaboradorService';
import {Colaborador} from 'src/app/model-landing/colaborador';
import {MessageService} from 'primeng/api';
import {BlockUI, NgBlockUI} from 'ng-block-ui';
import {ParametroService} from 'src/app/service-landing/ParametroService';

@Component({
    selector: 'app-component-colaborador',
    templateUrl: './component-colaborador.component.html',
    styleUrls: ['./component-colaborador.component.css'],
    providers: [MessageService]
})
export class ComponentColaboradorComponent implements OnInit {

    colaborador: Colaborador;

    editNroDocumento: any;
    editNombres: string;
    editApellidos: string;
    editNroTelefono: string;
    editEmail: string;
    editCargo: string;
    editMarca: string;
    editLocal: string;
    listaEmpresa: any[];
    opcionSeleccionado = '0'; // Iniciamos
    @BlockUI() blockUI: NgBlockUI;
    codigo: any;


    constructor(private router: Router,
                private messageService: MessageService,
                private location: Location,
                private colaboradorService: ColaboradorService,
                private parametroService: ParametroService) {
        this.colaborador = new Colaborador();

    }

    ngOnInit(): void {
        this.iniciarListaEmpresa();
        this.obtenerLocalStorage();
    }

    iniciarListaEmpresa() {
        this.blockUI.start('Procesando ...');
        this.parametroService.obtenerListaEmpresa(ConstantesUtil.parametroTipoEmpresa).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaEmpresa = data.parametroList;
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }


    capturar() {
        this.colaborador.marca = this.opcionSeleccionado;
    }

    obtenerLocalStorage() {
        const obtenerColaborador = JSON.parse(sessionStorage.getItem('colaborador'));
        this.initPintarCampos(obtenerColaborador);

    }


    initPintarCampos(colaboradorData: any) {
        if (colaboradorData != null) {
            this.colaborador.documento = colaboradorData.documento;
            this.colaborador.nombres = colaboradorData.nombres;
            this.colaborador.apellidos = colaboradorData.apellidos;
            this.colaborador.telefono = colaboradorData.telefono;
            this.colaborador.email = colaboradorData.email;
            this.colaborador.cargo = colaboradorData.cargo;
            this.colaborador.marca = colaboradorData.marca;
            this.opcionSeleccionado = this.colaborador.marca;
            this.colaborador.local = colaboradorData.local;
        }

    }

    onClickIniciarRefente() {
        this.iniciarValidacionCampos();
    }

    numeroValidar(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }


    iniciarValidacionCampos() {
        if (this.colaborador.documento === '' || this.colaborador.documento === null || this.colaborador.documento === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el documento');
            return;
        }
        if (this.colaborador.documento.length < 8) {
            this.showMsgs('error', 'Error : ', 'Coloque el número documento correcto');
            return;
        }

        if (this.colaborador.nombres === '' || this.colaborador.nombres === null || this.colaborador.nombres === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el nombre completo');
            return;
        }
        if (this.colaborador.apellidos === '' || this.colaborador.apellidos === null || this.colaborador.apellidos === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el apellido completo');
            return;
        }
        if (this.colaborador.telefono === '' || this.colaborador.telefono === null || this.colaborador.telefono === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el telefono');
            return;
        }
        if (this.colaborador.telefono.length < 7) {
            this.showMsgs('error', 'Error : ', 'Coloque el número telefono correcto');
            return;
        }
        if (this.colaborador.email === '' || this.colaborador.email === null || this.colaborador.email === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el email');
            return;
        }


        if (this.colaborador.email.match(/[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9A-Z](?:[a-z0-9A-Z]*[a-z0-9A-Z])?\.)+[a-z0-9A-Z](?:[a-z0-9A-Z]*[a-z0-9A-Z])?/)) {
            console.log('null');
        } else {
            this.showMsgs('error', 'Error : ', 'Debe completar el email correcto');
            return;
        }

        if (this.colaborador.cargo === '' || this.colaborador.cargo === null || this.colaborador.cargo === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el cargo');
            return;
        }
        if (this.colaborador.marca === '' || this.colaborador.marca === null || this.colaborador.marca === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar la marca');
            return;
        }
        if (this.colaborador.local === '' || this.colaborador.local === null || this.colaborador.local === undefined) {
            this.showMsgs('error', 'Error : ', 'Debe completar el local');
            return;
        }
        this.initValidarUsuario();

    }

    initValidarUsuario() {
        this.initRegistrarColaborador();
    }

    initRegistrarColaborador() {
        this.blockUI.start('Procesando ...');
        this.colaboradorService.crearColaborador(this.colaborador).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.colaborador.id = data.id;
                this.initGrabarLocalStorage();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
                alert('Colaborador no creado');
            }

        });
    }

    initGrabarLocalStorage() {
        sessionStorage.setItem('colaborador', JSON.stringify(this.colaborador));
        this.navegarReferente();
    }


    initWacthNumeroDni($event) {
        const numeroDocumento = $event.target.value;
        if (numeroDocumento.length >= 8) {
            this.editNroDocumento = numeroDocumento;
            this.iniciarServicioNumeroDocumento(numeroDocumento);
        }
    }

    iniciarServicioNumeroDocumento(numeroDocumento: string) {
        this.blockUI.start('Procesando ...');
        this.colaboradorService.obtenerColaboradorPorDni(numeroDocumento).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.obteniendoColaboradorEncontrado(data);
                this.blockUI.stop();
            } else if (data.codigo === ConstantesUtil.codMsjNotValid) {
                this.obteniendoColaboradorEncontrado(data);
                this.codigo = data.codigo;
                console.log(data.codigo);
                this.blockUI.stop();
            } else {
                this.limpiarColaboradorNoEncontrado();
                console.log('Persona No existe ');
                this.blockUI.stop();
            }
        });
    }

    obteniendoColaboradorEncontrado(data: any) {
        this.colaborador.id = data.id;
        this.colaborador.documento = data.documento;
        this.colaborador.mensaje = data.mensaje;
        this.colaborador.nombres = data.nombres;
        this.colaborador.apellidos = data.apellidos;
        this.colaborador.telefono = data.telefono;
        this.colaborador.email = data.email;
        this.colaborador.cargo = data.cargo;
        this.colaborador.marca = data.marca;
        this.colaborador.local = data.local;
        this.opcionSeleccionado = this.colaborador.marca;
    }

    limpiarColaboradorNoEncontrado() {
        this.colaborador.id = null;
        this.colaborador.nombres = null;
        this.colaborador.telefono = null;
        this.colaborador.apellidos = null;
        this.colaborador.email = null;
        this.colaborador.cargo = null;
        this.colaborador.marca = null;
        this.colaborador.local = null;
        this.opcionSeleccionado = '0';
    }

    navegarReferente() {
        this.router.navigate([ConstantesUtil.talento + '/referente']);
    }

    onClickAtras() {
        this.location.back();
    }


    showMsgs(tipoMsg, titulo, msg) {
        this.messageService.add({severity: tipoMsg, summary: titulo, detail: msg});
    }

}
