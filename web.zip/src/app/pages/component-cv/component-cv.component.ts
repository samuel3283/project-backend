import {Component, OnInit, ViewChild, ElementRef} from '@angular/core';
import {Router} from '@angular/router';
import {CvService} from 'src/app/service-landing/CvService';
import {Recomendacion} from 'src/app/model-landing/recomendacion';
import {ConstantesUtil} from 'src/app/util/constantesUtil';
import {Location} from '@angular/common';
import {RecomendadoService} from 'src/app/service-landing/RecomendadoService';
import {BlockUI, NgBlockUI} from 'ng-block-ui';


@Component({
    selector: 'app-component-cv',
    templateUrl: './component-cv.component.html',
    styleUrls: ['./component-cv.component.css'],
    styles: []
})
export class ComponentCvComponent implements OnInit {

    @ViewChild('inputFile') myInputVariable: ElementRef;

    nombreRecomendado: string;
    referente: any;
    colaborador: any;
    recomendado: any;
    subirArchivoAll: File = null;
    nombreDelArchivo: string;
    extensionDelArchivo: string;
    nombreImagen: String;

    @BlockUI() blockUI: NgBlockUI;


    constructor(private router: Router,
                private cvService: CvService,
                private location: Location,
                private recomendadoService: RecomendadoService) {
    }

    ngOnInit(): void {
        const sesionIdRecomendado = sessionStorage.getItem('idRecomendado');
        console.log(sesionIdRecomendado);
        this.referente = JSON.parse(sessionStorage.getItem('referente'));
        this.colaborador = JSON.parse(sessionStorage.getItem('colaborador'));
        this.nombreRecomendado = this.referente.nombres + ' ' + this.referente.apellidos;
        this.validacionStorage();
    }

    validacionStorage() {
        if (this.colaborador == null) {
            this.regresarColaborador();
            return;
        }
    }

    regresarColaborador() {
        this.router.navigate([ConstantesUtil.talento + '/colaborador']);
    }

    onClickRegresar() {
        this.location.back();
    }


    onClickContinuarCv2() {
        const encuesta = JSON.parse(sessionStorage.getItem('encuesta'));
        const myObjStr = JSON.stringify(encuesta);
        console.log(myObjStr);
        this.iniciarRegistroData(encuesta);
    }

    iniciarRegistroData(data: any) {
        this.blockUI.start('Procesando ...');

        this.recomendadoService.crearRecomendados(data).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                sessionStorage.setItem('resultadoCalifacion', data.resultadoCalifacion);
                sessionStorage.setItem('idRecomendado', data.idRecomendado);
                sessionStorage.setItem('montoPorPuesto', data.montoPorPuesto);
                if (this.subirArchivoAll != null) {
                    const recomendacion = new Recomendacion();
                    recomendacion.idRecomendado = data.idRecomendado; //Este valor depende de la respuesta
                    recomendacion.idPuesto = this.referente.idPuesto;
                    recomendacion.idColaborador = this.colaborador.id;
                    recomendacion.extensionDelArchivo = this.extensionDelArchivo;
                    recomendacion.dniRecomendado = this.referente.dni;
                    this.cvService.actualizarCv(this.subirArchivoAll).subscribe(data => {
                        this.blockUI.stop();
                        this.validacionResultadoCalifacion();
                    });
                } else {
                    this.blockUI.stop();
                    this.validacionResultadoCalifacion();
                }
            }
        });
    }


    onClickContinuarCv() {
        const encuesta = JSON.parse(sessionStorage.getItem('encuesta'));
        this.iniciarRegistroData(encuesta);
    }


    subirArchivo(files: any) {
        this.subirArchivoAll = files.item(0);
        this.nombreDelArchivo = this.subirArchivoAll.name;
        if (this.nombreDelArchivo != null) {
            if (this.subirArchivoAll.name.endsWith('jpg') ||
                this.subirArchivoAll.name.endsWith('png') ||
                this.subirArchivoAll.name.endsWith('doc') ||
                this.subirArchivoAll.name.endsWith('docx') ||
                this.subirArchivoAll.name.endsWith('pdf') ||
                this.subirArchivoAll.name.endsWith('JPG') ||
                this.subirArchivoAll.name.endsWith('PNG') ||
                this.subirArchivoAll.name.endsWith('DOC') ||
                this.subirArchivoAll.name.endsWith('DOCX') ||
                this.subirArchivoAll.name.endsWith('DOCX') ||
                this.subirArchivoAll.name.endsWith('PNG')
            ) {
                this.extensionDelArchivo = this.subirArchivoAll.name.split('.').pop();
            } else {
                this.subirArchivoAll = null;
                this.myInputVariable.nativeElement.value = '';
                alert('No se permite tipo archivo, intente con otro');
            }
        }
    }


    validacionResultadoCalifacion() {
        const resultadoCalifacion = sessionStorage.getItem('resultadoCalifacion');
        if (resultadoCalifacion == 'Rechazado') {
            this.iniciarNavegadorRechazado();
            return;
        }
        if (resultadoCalifacion == 'Califica') {
            this.iniciarNavegadorCalificado();
            return;
        }
    }

    iniciarNavegadorRechazado() {
        this.router.navigate([ConstantesUtil.talento + '/respuestanegativa']);
    }

    iniciarNavegadorCalificado() {
        this.router.navigate([ConstantesUtil.talento + '/respuestapositiva']);
    }


}


