import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ConstantesUtil} from 'src/app/util/constantesUtil';
import {Location} from '@angular/common';
import {MessageService} from 'primeng/api';
import {PreguntaService} from 'src/app/service-landing/PreguntaService';
import {UbigeoService} from 'src/app/service-landing/UbigeoService';
import {Pregunta} from 'src/app/model-landing/pregunta';
import {RecomendadoService} from 'src/app/service-landing/RecomendadoService';
import {BlockUI, NgBlockUI} from 'ng-block-ui';


@Component({
    selector: 'app-component-encuesta',
    templateUrl: './component-encuesta.component.html',
    styleUrls: ['./component-encuesta.component.css'],
    providers: [MessageService]
})
export class ComponentEncuestaComponent implements OnInit {

    listaPreguntasPadre: Pregunta[];
    listaDepartamento = [];
    nombreReferenteInicial: string;
    nombreReferenteFinal: string;
    referente: any;
    colaborador: any;

    parametroSeleccionado: string;

    opcionSeleccionado = '0'; // Iniciamos
    verSeleccion: string;


    @BlockUI() blockUI: NgBlockUI;

    constructor(private router: Router,
                private messageService: MessageService,
                private location: Location,
                private preguntarService: PreguntaService,
                private ubigeoService: UbigeoService,
                private recomendadoService: RecomendadoService) {
    }

    ngOnInit(): void {
        this.iniciarListaDepartamentoService('nombreDepartamento');
        this.referente = JSON.parse(sessionStorage.getItem('referente'));
        this.colaborador = JSON.parse(sessionStorage.getItem('colaborador'));
        this.obtenerLocalStorage();
        this.iniciarListaPreguntas();

    }

    iniciarListaPreguntas() {
        const idPuesto = this.referente.idPuesto;
        const evento = this.referente.evento;
        this.blockUI.start('Procesando ...');
        this.preguntarService.obtenerListaPreguntaPorPuesto(idPuesto, evento).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaPreguntasPadre = data.preguntaList;
                this.obtenerEncuestaGrabada();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    obtenerEncuestaGrabada() {
        const respuestaPregunta = JSON.parse(sessionStorage.getItem('respuestaPregunta'));

        const myObjStr = JSON.stringify(respuestaPregunta);
        console.log(myObjStr);

        if (respuestaPregunta != null) {
            this.listaPreguntasPadre.forEach((padre, index) => {
                padre;
                respuestaPregunta.forEach((pregunta, index) => {
                    pregunta;
                    if (padre.id === pregunta.idPregunta) {
                        padre.opcionRespuestas.forEach((hijo, index) => {
                            hijo;
                            respuestaPregunta.forEach((respuesta, index) => {
                                respuesta;
                                if (hijo.idTipoPregunta == ConstantesUtil.tipo_pregunta_radio_button) {
                                    if (hijo.id === respuesta.idOpcionRespuesta) {
                                        padre.respuestaEnunciado = respuesta.respuestaEnunciado;
                                        padre.idRespuesta = respuesta.idOpcionRespuesta;
                                    }
                                }

                                if (hijo.idTipoPregunta == ConstantesUtil.tipo_pregunta_auto_complete) {
                                    padre.idRespuesta = respuesta.idOpcionRespuesta;
                                    padre.respuestaAutocomplete = respuesta.respuestaAutocomplete;
                                }
                            });
                        });
                    }
                });
            });
        }

        for (const padre of this.listaPreguntasPadre) {
            if (padre.idTipoPregunta == ConstantesUtil.tipo_pregunta_auto_complete) {
                for (const departamento of this.listaDepartamento) {
                    if (departamento.id == padre.idRespuesta) {
                        this.opcionSeleccionado = departamento.id;
                        break;
                    }
                }
            }
        }
    }


    iniciarListaDepartamentoService(nombreDepartamento: string) {
        this.ubigeoService.buscarDepartamentoCritico().subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaDepartamento = data.departamentoList;
            }
        });
    }

    validarDepartamentosSelecionados() {

        for (const padre of this.listaPreguntasPadre) {
            if (padre.idTipoPregunta == ConstantesUtil.tipo_pregunta_auto_complete) {
                for (const departamento of this.listaDepartamento) {
                    if (departamento.id === padre.idRespuesta) {
                        this.opcionSeleccionado = departamento.id;
                        break;
                    }
                }

            }

        }
    }

    capturar(padre: any) {
        this.verSeleccion = this.opcionSeleccionado;
        const updateItem = this.listaPreguntasPadre.find(item => item.id === padre.id);
        const index = this.listaPreguntasPadre.indexOf(updateItem);
        this.listaPreguntasPadre[index].idRespuesta = this.opcionSeleccionado;
        this.listaPreguntasPadre[index].respuestaAutocomplete = {
            id: this.opcionSeleccionado,
            nombre: 'depa',
            estado: 'A'
        };
    }

    initWacthDepartamento(event) {
        const nombreDepartamento = event.query;
        if (nombreDepartamento.length > 0) {
            this.iniciarListaDepartamentoService(nombreDepartamento);
        }
    }

    obtenerLocalStorage() {
        if (this.colaborador == null) {
            this.regresarColaborador();
            return;
        }

        if (this.colaborador.documento === '' || this.colaborador.documento === null || this.colaborador.documento === undefined) {
            this.regresarColaborador();
            return;
        }
        if (this.referente.dni === '' || this.referente.dni === null || this.referente.dni === undefined) {
            this.regresarReferente();
            return;
        }
        this.initValidarTipoPuesto();

    }

    initValidarTipoPuesto() {
        this.nombreReferenteInicial = '¿ ' + this.referente.nombres + ' ' + this.referente.apellidos + ' ';
        /*if(this.referente.idPuesto == 1){
            this.nombreReferenteInicial = "¿ "+this.referente.nombres+" "+this.referente.apellidos+ " ";
        }else{
            this.nombreReferenteFinal =  " "+this.referente.nombres+" "+this.referente.apellidos+  " ? ";
        }*/
    }

    regresarColaborador() {
        this.router.navigate([ConstantesUtil.talento + '/colaborador']);
    }

    regresarReferente() {
        this.router.navigate([ConstantesUtil.talento + '/referente']);
    }


    selectOpcionesPreguntas(hijo: any, padre: any) {
        const updateItem = this.listaPreguntasPadre.find(item => item.id === padre.id);
        const index = this.listaPreguntasPadre.indexOf(updateItem);
        this.listaPreguntasPadre[index].idRespuesta = hijo.id;
        this.listaPreguntasPadre[index].respuestaEnunciado = hijo.enunciado;
        console.log(this.listaPreguntasPadre);

    }

    onSelectAutoComplete(hijo: any, padre: any) {
        //alert(this.verSeleccion);
        const updateItem = this.listaPreguntasPadre.find(item => item.id === padre.id);
        const index = this.listaPreguntasPadre.indexOf(updateItem);
        this.listaPreguntasPadre[index].idRespuesta = this.verSeleccion;
        this.listaPreguntasPadre[index].respuestaAutocomplete = {
            id: this.verSeleccion,
            nombre: 'depa',
            estado: 'A'
        };
        console.log(this.listaPreguntasPadre);
    }

    onClickAtras() {
        this.location.back();
    }

    showMsgs(tipoMsg, titulo, msg) {
        this.messageService.add({severity: tipoMsg, summary: titulo, detail: msg});
    }

    onClickContinuar() {
        for (var padre of this.listaPreguntasPadre) {
            if (padre.idRespuesta == null) {
                if (padre.idTipoPregunta == '1') {//Radio Button
                    let index = this.listaPreguntasPadre.indexOf(padre);
                    var sum = [index + 1];
                    alert(' Te falta completar la pregunta  ' + sum);
                    return;
                }
                if (padre.idTipoPregunta == '2') {//Auto COmplete
                    let index = this.listaPreguntasPadre.indexOf(padre);
                    var sum = [index + 1];
                    alert(' Te falta seleccionar algun departamento  ' + sum);
                    return;
                }
            }
        }
        const respuestaPregunta = [];
        for (const padre of this.listaPreguntasPadre) {
            respuestaPregunta.push({
                idOpcionRespuesta: padre.idRespuesta,
                idPregunta: padre.id,
                respuestaEnunciado: padre.respuestaEnunciado,
                respuestaAutocomplete: padre.respuestaAutocomplete
            });
        }

        console.log(this.listaPreguntasPadre);
        console.log(respuestaPregunta);
        this.iniciarCreacionJSON(respuestaPregunta);
    }

    iniciarCreacionJSON(respuestaPregunta: any) {
        const myDate = new Date();
        const registroData = {
            nombreUbigeo: this.referente.nombreDistrito + ' , ' + this.referente.nombreProvincia + ' , ' + this.referente.nombreDepartamento,
            idDistrito: this.referente.idDistrito,
            idDepartamento: this.referente.idDepartamento,
            idProvincia: this.referente.idProvincia,
            id: this.referente.idRecomendado,
            fechaCreacion: myDate,
            nombre: this.referente.nombres,
            apellido: this.referente.apellidos,
            numeroDocumento: this.referente.dni,
            idPuesto: this.referente.idPuesto,
            idParametro: this.referente.idTipoParametro,
            telefono: this.referente.telefono,
            idCarrera: this.referente.idCarrera,
            evento: this.referente.evento,
            recomendaciones: [{
                idColaborador: this.colaborador.id,
                cv: 'string',
                fechaRecomendacion: '2020-07-14T02:54:02.102Z',
                idPuesto: this.referente.idPuesto,
                idRecomendado: 0,
                recomendacionRespuestas: respuestaPregunta
            }]
        };
        const myObjStr = JSON.stringify(registroData);
        console.log(myObjStr);
        sessionStorage.setItem('encuesta', JSON.stringify(registroData));
        sessionStorage.setItem('respuestaPregunta', JSON.stringify(respuestaPregunta));
        this.iniciarInsertacionCV();

    }

    iniciarRegistroData(data: any) {
        this.blockUI.start('Procesando ...');
        this.recomendadoService.crearRecomendados(data).subscribe(data => {
            if (data) {
                if (data.codigo === ConstantesUtil.codMsjOk) {
                    console.log('resultadoCalifacion ' + data.resultadoCalifacion);
                    console.log('idRecomendado ' + data.idRecomendado);
                    sessionStorage.setItem('resultadoCalifacion', data.resultadoCalifacion);
                    sessionStorage.setItem('idRecomendado', data.idRecomendado);
                    this.blockUI.stop();
                    this.iniciarInsertacionCV();
                }
            } else {
                this.blockUI.stop();
                this.showMsgs('success', 'Atención : ', 'El Referido ya fue registrado anteriormente');
                this.router.navigate(['/talento/landing']);
            }

        });
    }

    grabarResultado(resultadoCalifacion: any, idRecomendado: any) {
        localStorage.setItem('resultadoCalifacion', resultadoCalifacion);
        localStorage.setItem('idRecomendado', idRecomendado);
    }

    iniciarInsertacionCV() {
        this.router.navigate([ConstantesUtil.talento + '/cv']);
    }

    iniciarNavegadorRechazado() {
        this.router.navigate([ConstantesUtil.talento + '/respuestanegativa']);
    }

    iniciarNavegadorCalificado() {
        this.router.navigate([ConstantesUtil.talento + '/respuestapositiva']);
    }

}


