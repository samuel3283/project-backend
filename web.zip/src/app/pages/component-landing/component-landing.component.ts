import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ConstantesUtil} from 'src/app/util/constantesUtil';

import {ImagesService} from 'src/app/service-landing/ImagesService';

@Component({
    selector: 'app-component-landing',
    templateUrl: './component-landing.component.html',
    styleUrls: ['./component-landing.component.css'],
})
export class ComponentLandingComponent implements OnInit {

    imagePath: string;

    constructor(private router: Router,
                private imageService: ImagesService) {
    }

    ngOnInit(): void {
        sessionStorage.clear();
        this.iniciarImagenesModulo();
    }

    iniciarImagenesModulo() {
        this.imageService.obtenerImagenModulo(ConstantesUtil.moduloLanding).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.imagePath = data.url;
            }
        });
    }

    onClickRegistroColaborador() {
        this.navegarColaborador();
    }

    navegarColaborador() {
        //window.open('https://forms.gle/Cwiui57ah1C597j59', '_self');// nueva pesataña
        window.location.replace('https://forms.gle/Cwiui57ah1C597j59');
        //this.router.navigate([ConstantesUtil.formTalento]);
    }

}
