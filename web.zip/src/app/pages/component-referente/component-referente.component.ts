import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ConstantesUtil} from 'src/app/util/constantesUtil';
import {ParametroService} from 'src/app/service-landing/ParametroService';

import {Location} from '@angular/common';
import {Referente} from 'src/app/model-landing/referente';
import {PuestoService} from 'src/app/service-landing/PuestoService';
import {MessageService} from 'primeng/api';
import {UbigeoService} from 'src/app/service-landing/UbigeoService';
import {BlockUI, NgBlockUI} from 'ng-block-ui';
import {CarreraService} from 'src/app/service-landing/CarreraService';
import {RecomendadoService} from '../../service-landing/RecomendadoService';

@Component({
    selector: 'app-component-referente',
    templateUrl: './component-referente.component.html',
    styleUrls: ['./component-referente.component.css'],
    providers: [MessageService]
})
export class ComponentReferenteComponent implements OnInit {

    listaParametro: any[];
    listaPuesto: any[];
    listaDistritos: any[];
    referente: Referente;
    distritoSeleccionado: any;
    parametroSeleccionado: string;
    puestoSeleccionado: string;
    concatUbigeoStr: string;


    listaCarrera: any[];
    carreraSeleccionado = '0';

    @BlockUI() blockUI: NgBlockUI;
    statusRecomendadoPorDni = false;


    constructor(private router: Router,
                private messageService: MessageService,
                private location: Location,
                private parametroService: ParametroService,
                private puestoService: PuestoService,
                private ubigeoService: UbigeoService,
                private recomendadoService: RecomendadoService,
                private carreraService: CarreraService) {
        this.referente = new Referente();
        this.referente.evento = 2;
    }

    ngOnInit(): void {

        this.obtenerLocalStorage();
        this.obtenerListaParametro();
        this.obtenerListaPuesto();
        this.pintarCamposReferente();
    }


    obtenerListaPuesto() {
        this.blockUI.start('Procesando ...');
        this.puestoService.obtenerListaPuesto().subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaPuesto = data.puestoListaResponseList;
                this.iniciarBusquedaPuesto();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    obtenerListaParametro() {
        this.blockUI.start('Procesando ...');
        this.parametroService.obtenerListaParametro(ConstantesUtil.parametroTipoFamiliarRelacion).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaParametro = data.parametroList;
                this.iniciarBusquedaParametro();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    initWacthNumeroDni($event) {
        const numeroDocumento = $event.target.value;
        if (numeroDocumento.length >= 8) {
            this.iniciarServicioNumeroDocumento(numeroDocumento);
        } else {
            this.referente.idRecomendado = null;
        }
    }

    iniciarServicioNumeroDocumento(numeroDocumento: string) {
        this.blockUI.start('Procesando ...');
        this.recomendadoService.obtenerRecomendadoPorDni(numeroDocumento).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                const estadoReferente = data.estadoRecomendado;
                this.validacionEstadoReferente(estadoReferente, data);
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
                this.referente.idRecomendado = null;
                this.statusRecomendadoPorDni = false;
            }
        });
    }

    validacionEstadoReferente(estadoRefente: any, data: any) {
        if (estadoRefente === ConstantesUtil.tipo_estado_contratado) {
            this.showMsgs('error', 'Error : ', 'El Referente que deseas recomendar, ya se encuentra contratado');
            this.statusRecomendadoPorDni = true;
        } else {
            if (data.tipoRegistro === 'landing') {
                this.statusRecomendadoPorDni = true;
                this.showMsgs('error', 'Error : ', 'El Referente ya inicio proceso de evaluación');
            } else {
                if (data.diasFaltantes <= 0) {
                    this.statusRecomendadoPorDni = false;
                    this.referente.idRecomendado = data.idRecomendado;
                    this.referente.nombres = data.nombreRecomendado;
                    this.referente.apellidos = data.apellidoRecomendado;
                    this.referente.telefono = data.numeroTelefonoRecomendado;
                } else {
                    this.statusRecomendadoPorDni = true;
                    this.showMsgs('error', 'Error : ', 'El Referente esta medio proceso de evaluación');
                }

            }

        }
    }

    numeroValidar(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    obtenerLocalStorage() {
        const obtenerColaborador = JSON.parse(sessionStorage.getItem('colaborador'));
        if (obtenerColaborador == null) {
            this.regresarColaborador();
            return;
        }

    }


    pintarCamposReferente() {
        const referenteGet = JSON.parse(sessionStorage.getItem('referente'));
        if (referenteGet != null) {

            this.referente.nombres = referenteGet.nombres;
            this.referente.apellidos = referenteGet.apellidos;
            this.referente.dni = referenteGet.dni;
            this.referente.telefono = referenteGet.telefono;
            this.distritoSeleccionado = {
                idDistrito: referenteGet.idDistrito,
                nombreDistrito: referenteGet.nombreDistrito,
                idProvincia: referenteGet.idProvincia,
                idDepartamento: referenteGet.idDepartamento,
                nombreProvincia: referenteGet.nombreProvincia,
                concatDistrito: referenteGet.concatUbigeo,
                nombreDepartamento: referenteGet.nombreDepartamento
            };

            this.referente.idTipoParametro = referenteGet.idTipoParametro;
            this.referente.idPuesto = referenteGet.idPuesto;

            this.referente.idCarrera = referenteGet.idCarrera;
            this.iniciarListaCarreraPorPuesto(this.referente.idPuesto);


            this.referente.idDistrito = this.distritoSeleccionado.idDistrito;
            this.referente.idDepartamento = this.distritoSeleccionado.idDepartamento;
            this.referente.idProvincia = this.distritoSeleccionado.idProvincia;
            this.referente.nombreDistrito = this.distritoSeleccionado.nombreDistrito;
            this.referente.nombreDepartamento = this.distritoSeleccionado.nombreDepartamento;
            this.referente.nombreProvincia = this.distritoSeleccionado.nombreProvincia;
            this.concatUbigeoStr = this.distritoSeleccionado.nombreDistrito + ',' + this.distritoSeleccionado.nombreProvincia;
            this.referente.concatUbigeo = this.concatUbigeoStr + ',' + this.distritoSeleccionado.nombreDepartamento;


        }

    }

    iniciarBusquedaPuesto() {
        for (const puesto of this.listaPuesto) {
            if (puesto.id === this.referente.idPuesto) {
                this.puestoSeleccionado = puesto.descripcion;
                return;
            }
        }
    }

    iniciarBusquedaParametro() {
        for (const parametro of this.listaParametro) {
            if (parametro.id === this.referente.idTipoParametro) {
                this.parametroSeleccionado = parametro.valor;
                return;
            }
        }
    }

    regresarColaborador() {
        this.router.navigate([ConstantesUtil.talento + '/colaborador']);
    }

    onClickAtras() {
        this.location.back();
    }

    onClickIniciarPreguntas() {
        if (this.statusRecomendadoPorDni) {
            this.showMsgs('error', 'Error : ', 'Intente con otro persona');
            return;
        }
        this.initValidarCampos();
    }

    initValidarCampos() {
        if (this.referente.nombres === '' || this.referente.nombres === null || this.referente.nombres === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete nombre referente');
            return;
        }
        if (this.referente.apellidos === '' || this.referente.apellidos === null || this.referente.apellidos === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete apellidos referente');
            return;
        }
        if (this.referente.dni === '' || this.referente.dni === null || this.referente.dni === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete dni referente');
            return;
        }
        if (this.referente.dni.length < 8) {
            this.showMsgs('error', 'Error : ', 'Coloque el número dni correcto');
            return;
        }
        if (this.referente.telefono === '' || this.referente.telefono === null || this.referente.telefono === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete telefono referente');
            return;
        }
        if (this.referente.telefono.length < 7) {
            this.showMsgs('error', 'Error : ', 'Coloque el número telefono correcto');
            return;
        }

        if (this.referente.nombreDistrito === '' || this.referente.nombreDistrito === null || this.referente.nombreDistrito === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete distrito referente');
            return;
        }
        if (this.referente.idTipoParametro === '' || this.referente.idTipoParametro === null || this.referente.idTipoParametro === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete tipo relacion del referente');
            return;
        }
        if (this.referente.idPuesto === '' || this.referente.idPuesto === null || this.referente.idPuesto === undefined) {
            this.showMsgs('error', 'Error : ', 'Complete puesto del referente');
            return;
        }
        if (this.referente.idCarrera === '' || this.referente.idCarrera === null || this.referente.idCarrera === undefined) {
            this.showMsgs('error', 'Error : ', 'Seleccione la carrera');
            return;
        }
        this.initGrabarLocalStorage();
    }

    initGrabarLocalStorage() {
        sessionStorage.setItem('referente', JSON.stringify(this.referente));
        this.navegarPreguntas();
    }

    navegarPreguntas() {
        this.router.navigate([ConstantesUtil.talento + '/encuesta']);
    }

    onSelectedParametro(parametro: any) {
        this.referente.idTipoParametro = parametro.id;
    }

    onSelectedPuesto(puesto: any) {
        if (puesto.id !== this.referente.idPuesto) {
            this.carreraSeleccionado = '0';
            this.referente.idCarrera = null;
            this.referente.idPuesto = puesto.id;
            this.iniciarListaCarreraPorPuesto(this.referente.idPuesto);
            return;
        }
        this.referente.idPuesto = puesto.id;
        this.iniciarListaCarreraPorPuesto(this.referente.idPuesto);
    }

    iniciarListaCarreraPorPuesto(idPuesto: string) {
        this.carreraService.obtenerCarreraPorPuesto(idPuesto).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaCarrera = data.carreraList;
                this.validacionCarreraLlena();
            }
        });
    }

    validacionCarreraLlena() {
        if (this.referente.idCarrera != null) {
            for (const carrera of this.listaCarrera) {
                const carreraID = carrera.id + '';
                const carrrera = this.referente.idCarrera + '';
                if (carreraID === carrrera) {
                    this.carreraSeleccionado = carrera.id;
                    this.referente.idCarrera = this.carreraSeleccionado;
                    break;
                }
            }
        }
    }

    capturarCarrera() {
        this.referente.idCarrera = this.carreraSeleccionado;
    }

    showMsgs(tipoMsg, titulo, msg) {
        this.messageService.add({severity: tipoMsg, summary: titulo, detail: msg});
    }

    initWacthDistrito(event) {
        var nombreDistrito = event.query;
        if (nombreDistrito.length > 2) {
            this.iniciarBuscarDistritoPorNombre(nombreDistrito);
        } else {
            this.initLimpiarReferenteDistrito();
        }
    }

    iniciarBuscarDistritoPorNombre(nombreDistrito: string) {
        this.ubigeoService.buscarDistritoPorNombre(nombreDistrito).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaDistritos = data.distritoDtoList;
            }
        });
    }

    onSelectDistrito(event) {
        this.referente.idDistrito = event.idDistrito;
        this.referente.idDepartamento = event.idDepartamento;
        this.referente.idProvincia = event.idProvincia;
        this.referente.nombreDistrito = event.nombreDistrito;
        this.referente.nombreDepartamento = event.nombreDepartamento;
        this.referente.nombreProvincia = event.nombreProvincia;
        this.referente.concatUbigeo = event.nombreDistrito + ',' + event.nombreProvincia + ',' + event.nombreDepartamento;
    }

    initLimpiarReferenteDistrito() {
        this.referente.nombreDistrito = null;
        this.referente.idDistrito = null;
        this.referente.idDepartamento = null;
        this.referente.idProvincia = null;
    }


}
