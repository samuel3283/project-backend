import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConstantesUtil } from 'src/app/util/constantesUtil';



@Component({
  selector: 'app-component-respuestanegativa',
  templateUrl: './component-respuestanegativa.component.html',
  styleUrls: ['./component-respuestanegativa.component.css'],
})
export class ComponentRespuestaNegativaComponent implements OnInit {

  nombreRecomendado:string;
  referente:any;
  constructor(private router: Router) { 
  
  }

  ngOnInit(): void {
    this.obtenerLocalStorage();
 
  }
 

  obtenerLocalStorage(){
    this.referente = JSON.parse(sessionStorage.getItem("referente"));
    if(this.referente==null){
      this.regresarColaborador();
      return;
    }
    this.nombreRecomendado = this.referente.nombres+" "+this.referente.apellidos;
    if(this.nombreRecomendado==null){
      this.regresarColaborador();
      return;
    }
   
  }

  onClickInicio(){
    sessionStorage.removeItem("resultadoCalifacion");
    sessionStorage.removeItem("colaborador");
    sessionStorage.removeItem("montoPorPuesto");
    sessionStorage.removeItem("referente");
    sessionStorage.removeItem("encuesta");
    sessionStorage.removeItem("respuestaPregunta");
    sessionStorage.removeItem("idRecomendado");
    this.router.navigate([ConstantesUtil.talento + '/landing']);
  }

  regresarColaborador() {
    this.router.navigate([ConstantesUtil.talento + '/colaborador']);
  }

}


