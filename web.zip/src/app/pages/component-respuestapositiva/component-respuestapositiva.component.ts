import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConstantesUtil } from 'src/app/util/constantesUtil';
import { ParametroService } from 'src/app/service-landing/ParametroService';
import { BlockUI, NgBlockUI } from 'ng-block-ui';

@Component({
  selector: 'app-component-respuestapositiva',
  templateUrl: './component-respuestapositiva.component.html',
  styleUrls: ['./component-respuestapositiva.component.css'],
  styles: []
})
export class ComponentRespuestaPositivaComponent implements OnInit {

  nombreRecomendado: string;
  referente: any;
  variablePeriodoPrueba: string;
  variableMontoTarjeta = '0';
  variableEmailSeleccion: string;

  @BlockUI() blockUI: NgBlockUI;

  constructor(private router: Router,
    private parametroService: ParametroService) { }

  ngOnInit(): void {
   this.obtenerLocalStorage();
   this.obtenerTiempoPeriodo();
  }

  obtenerTiempoPeriodo() {
    this.blockUI.start('Procesando ...');
    this.parametroService.obtenerTiempoPeriodo(ConstantesUtil.parametroTiempoPeriodo).subscribe(data => {
      if (data.codigo === ConstantesUtil.codMsjOk) {
       this.variablePeriodoPrueba = data.valorParametro;
       this.variableEmailSeleccion = data.correoParametro;
       this.blockUI.stop();
      } else {
        this.blockUI.stop();
      }
    });
  }

  obtenerLocalStorage() {
    this.referente = JSON.parse(sessionStorage.getItem('referente'));
    if (this.referente == null) {
      this.regresarColaborador();
      return;
    }
    this.nombreRecomendado = this.referente.nombres + ' ' + this.referente.apellidos;
    if (this.nombreRecomendado == null ) {
      this.regresarColaborador();
      return;
    }
    let montoPorPuesto = sessionStorage.getItem('montoPorPuesto');
    let resultadoCalifacion = sessionStorage.getItem('resultadoCalifacion');
    this.variableMontoTarjeta = montoPorPuesto + ' soles';
    this.validarVariableCalificacion(resultadoCalifacion);
  }
  validarVariableCalificacion(resultadoCalifacion: any) {

    if (resultadoCalifacion == 'Rechazado') {
      this.iniciarNavegadorRechazado();
    }
    if (resultadoCalifacion == 'Califica') {
      this.iniciarNavegadorCalificado();
    }
  }
  iniciarNavegadorRechazado() {
    this.router.navigate([ConstantesUtil.talento + '/respuestanegativa']);
  }
  iniciarNavegadorCalificado() {
    this.router.navigate([ConstantesUtil.talento + '/respuestapositiva']);
  }

  onClickInicio() {
    sessionStorage.removeItem('resultadoCalifacion');
    sessionStorage.removeItem('colaborador');
    sessionStorage.removeItem('montoPorPuesto');
    sessionStorage.removeItem('referente');
    sessionStorage.removeItem('encuesta');
    sessionStorage.removeItem('respuestaPregunta');
    sessionStorage.removeItem('idRecomendado');
    this.router.navigate([ConstantesUtil.talento + '/landing']);
  }

  regresarColaborador() {
    this.router.navigate([ConstantesUtil.talento + '/colaborador']);
  }

}


