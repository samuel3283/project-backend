import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConstantesUtil } from '../../util/constantesUtil';
import { environment } from 'src/environments/environment';
import { MenuItem } from 'primeng/api/primeng-api';

@Component({
  selector: 'app-inicio',
  templateUrl: './inicio.component.html',
  styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {

  statusTabsRequerimiento = false;
  statusTabsConsolidado = false;
  statusTabsConfiguracion= false;
  items: MenuItem[]
  itemsPerfil: MenuItem[];

  activarTabsRequerimiento: boolean = false;
  activarTabsConsolidado: boolean = false;
  activarTabsConfiguracion: boolean = false;
  activarTabsConfiguracionListPersonal: boolean = false;
  activarTabsConfiguracionListTiendas: boolean = false;
  activarTabsConfiguracionListProveedor: boolean = false;
  activarTabsConfiguracionListConceptos: boolean = false;

  usuarioLogeado: any;
  modulosUsuarioLogeadoLista: any[];
  modulosTabsConfiguracionLista: any[];

  nombreStr: string;
  emailStr: string;
  puestoStr: string;
  idOrgaStr: any;
  nombreOrgaStr: string;

  constructor(private router: Router) {

  }

  ngOnInit() {
    /*this.sesionService.validarExistenciaToken();

    this.router.navigate([ConstantesUtil.capexInicio]);

    const userLogin = sessionStorage.getItem('usuarioLogeado');
    this.usuarioLogeado = JSON.parse(userLogin);
    console.log('usuario logeado : ' + JSON.stringify(this.usuarioLogeado));
    const modulosLista = sessionStorage.getItem('modulosUsuarioLogeadoLista');
    this.modulosUsuarioLogeadoLista = JSON.parse(modulosLista);
    this.initValidarPuesto();
    this.initValidarOrganizacion();
    this.initDatosPerfil();
    this.initStatusTabs();
    this.initModulo();
    //this.initMenuUsuarioLogin();*/
  }

  initModulo(){

  }

  initValidarPrimeraInstancia(){
    //BotonRequerimiento
    if(this.activarTabsRequerimiento){
      this.onClickRequerimiento()
      return;
    }

    if(this.activarTabsConsolidado){
      this.onClickConsolidados()
      return;
    }

    if(this.activarTabsConfiguracionListPersonal){
      this.initStatusTabsConfiguracion();
      this.navegarListarPersonal();
      return;
    }
    if(this.activarTabsConfiguracionListTiendas){
      this.initStatusTabsConfiguracion();
      this.navegarListarTiendas();
      return;
    }
    if(this.activarTabsConfiguracionListProveedor){
      this.initStatusTabsConfiguracion();
      this.navegarListarProveedores();
      return;
    }

    if(this.activarTabsConfiguracionListConceptos){
      this.initStatusTabsConfiguracion();
      this.navegarListarConceptos();
      return;
    }

  }


  initDatosPerfil(){
    this.nombreStr = this.usuarioLogeado.nombres;
    this.emailStr = this.usuarioLogeado.email;
    this.idOrgaStr = this.usuarioLogeado.idOrganizacion;
  }
  initValidarOrganizacion(){
    const idOrga = this.usuarioLogeado.idOrganizacion;
    if(idOrga == 0){
      this.nombreOrgaStr = 'Sin especificar'
    }else if(idOrga === 1){
      this.nombreOrgaStr = 'InkaFarma'
    }else if(idOrga === 2){
      this.nombreOrgaStr = 'MiFarma'
    }else{
      this.nombreOrgaStr = 'Sin especificar'
    }
  }
  initValidarPuesto(){
    const tipoPuesto = this.usuarioLogeado.idPuesto;

    if(tipoPuesto === 0){
      this.puestoStr = 'Sin especificar1'
    }else if(tipoPuesto === 1){
      this.puestoStr = 'Gerente de Infraestructura'
    }else if(tipoPuesto === 2){
      this.puestoStr = 'Jefe de Mantenimiento'
    }else if(tipoPuesto === 3){
      this.puestoStr = 'Supervisor de Mantenimiento'
    }else if(tipoPuesto === 4){
      this.puestoStr = 'Gerente de Proyectos'
    }else if(tipoPuesto === 5){
      this.puestoStr = 'Supervisor de Proyectos'
    }else if(tipoPuesto === 6){
      this.puestoStr = 'Asistente de Proyectos'
    }else if(tipoPuesto === 7){
      this.puestoStr = 'Gerente de Finanzas'
    }else{
      this.puestoStr = 'Sin especificar'
    }
  }


  initMenuUsuarioLogin(){

  }

  initMenuConfiguracion(){
    this.items = [];

    for(var i = 0; i < this.modulosTabsConfiguracionLista.length; i++) {
      const urlModulo = this.modulosTabsConfiguracionLista[i].urlModulo;
      this.initValidarDatosConfiguracion(urlModulo);
      this.items.push({
        label: this.modulosTabsConfiguracionLista[i].modulo, command: (event) => {
          this.navegarModulo(urlModulo);
          this.initStatusTabsConfiguracion();
        }
      });
    }
  }

  initValidarDatosConfiguracion(nombre:string){
    if(nombre == 'listadoPersonal'){
      this.activarTabsConfiguracionListPersonal = true;
    }else if(nombre == 'listadoTiendas'){
      this.activarTabsConfiguracionListTiendas = true;
    }else if(nombre == 'listadoProveedor'){
      this.activarTabsConfiguracionListProveedor = true;
    }else if (nombre == 'listadoConceptos'){
      this.activarTabsConfiguracionListConceptos = true;
    }else{
      this.activarTabsConfiguracionListPersonal = false;
      this.activarTabsConfiguracionListTiendas = false;
      this.activarTabsConfiguracionListProveedor = false;
      this.activarTabsConfiguracionListConceptos = false;
    }
  }


  initStatusTabsConfiguracion(){
    this.statusTabsRequerimiento = false;
    this.statusTabsConsolidado = false;
    this.statusTabsConfiguracion = true;
  }

  initStatusTabsRequerimientos(){
    this.statusTabsRequerimiento = true;
    this.statusTabsConsolidado = false;
    this.statusTabsConfiguracion = false;
  }
  initStatusTabsConsolidados(){
    this.statusTabsRequerimiento = false;
    this.statusTabsConsolidado = true;
    this.statusTabsConfiguracion = false;
  }

  initStatusTabs(){
    this.statusTabsRequerimiento = false;
    this.statusTabsConsolidado = false;
    this.statusTabsConfiguracion = false;
  }

  cerrarSesion(){
    sessionStorage.clear();
    location.href = environment.urlPortal;
  }

  navegarInicio(){
    this.router.navigate([ConstantesUtil.talento]);
  }

  onClickRequerimiento(){
    this.statusTabsRequerimiento = true;
    this.statusTabsConsolidado= false;
    this.statusTabsConfiguracion = false;
    this.navegarListarRequerimientos();
  }

  onClickConsolidados(){
    this.statusTabsConsolidado= true;
    this.statusTabsRequerimiento = false;
    this.statusTabsConfiguracion = false;
    this.navegarListarConsolidacionRequerimientos();
  }

  navegarModulo(urlModulo){
    this.router.navigate([ConstantesUtil.talento + '/' + urlModulo]);
  }

  navegarListarProveedores() {
    this.router.navigate([ConstantesUtil.talento + '/listadoProveedor']);
  }
  navegarListarPersonal() {
    this.router.navigate([ConstantesUtil.talento + '/listadoPersonal']);
  }
  navegarListarOrganizaciones(){
    this.router.navigate([ConstantesUtil.talento + '/listadoOrganizaciones']);
  }

  navegarListarTiendas() {
    this.router.navigate([ConstantesUtil.talento + '/listadoTiendas']);
  }

  navegarListarRequerimientos() {
    this.router.navigate([ConstantesUtil.talento + '/listadoRequerimientos']);
  }

  navegarListarConsolidacionRequerimientos() {
    this.router.navigate([ConstantesUtil.talento + '/listadoConsolidados']);
  }

  navegarListarConceptos() {
    this.router.navigate([ConstantesUtil.talento + '/listadoConceptos']);
  }

  navegarListarPartidas() {
    this.router.navigate([ConstantesUtil.talento + '/listadoPartidas']);
  }

}
