import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {PAGES_ROUTES} from './pages.routes';
import {FormsModule} from '@angular/forms';

import {BrowserModule} from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import {PrimengModule} from '../primeng/primeng.module';

import {BlockUIModule} from 'ng-block-ui';

import {DataTableModule} from '@pascalhonegger/ng-datatable';

import {PagesComponent} from './pages.component';
import {InicioComponent} from './inicio/inicio.component';

import {ComponentLandingComponent} from './component-landing/component-landing.component';
import {ComponentColaboradorComponent} from './component-colaborador/component-colaborador.component';
import {ComponentEncuestaComponent} from './component-encuesta/component-encuesta.component';
import {ComponentReferenteComponent} from './component-referente/component-referente.component';
import {ComponentCvComponent} from './component-cv/component-cv.component';
import {ComponentRespuestaPositivaComponent} from './component-respuestapositiva/component-respuestapositiva.component';
import {ComponentRespuestaNegativaComponent} from './component-respuestanegativa/component-respuestanegativa.component';


@NgModule({
    declarations: [
        PagesComponent,
        InicioComponent,
        ComponentLandingComponent,
        ComponentColaboradorComponent,
        ComponentReferenteComponent,
        ComponentEncuestaComponent,
        ComponentCvComponent,
        ComponentRespuestaPositivaComponent,
        ComponentRespuestaNegativaComponent,
    ],
    exports: [],
    imports: [
        FormsModule,
        BrowserModule,
        BrowserAnimationsModule,
        PAGES_ROUTES,
        HttpClientModule,
        BlockUIModule.forRoot(),
        PrimengModule,
        DataTableModule
    ],
    providers: []
})
export class PagesModule {
}
