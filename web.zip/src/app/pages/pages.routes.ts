import {PagesComponent} from './pages.component';
import {RouterModule, Routes} from '@angular/router';

import {ComponentLandingComponent} from './component-landing/component-landing.component';
import {ComponentColaboradorComponent} from './component-colaborador/component-colaborador.component';
import {ComponentReferenteComponent} from './component-referente/component-referente.component';
import {ComponentEncuestaComponent} from './component-encuesta/component-encuesta.component';
import {ComponentCvComponent} from './component-cv/component-cv.component';
import {ComponentRespuestaPositivaComponent} from './component-respuestapositiva/component-respuestapositiva.component';
import {ComponentRespuestaNegativaComponent} from './component-respuestanegativa/component-respuestanegativa.component';

const pagesRoutes: Routes = [
    {path: '', redirectTo: 'talento', pathMatch: 'full'},
    {
        path: 'talento', component: PagesComponent, children: [
            {path: 'landing', component: ComponentLandingComponent},
            {path: 'colaborador', component: ComponentColaboradorComponent},
            {path: 'referente', component: ComponentReferenteComponent},
            {path: 'encuesta', component: ComponentEncuestaComponent},
            {path: 'cv', component: ComponentCvComponent},
            {path: 'respuestapositiva', component: ComponentRespuestaPositivaComponent},
            {path: 'respuestanegativa', component: ComponentRespuestaNegativaComponent},
            {path: '', redirectTo: 'landing', pathMatch: 'full'},
        ]
    }
];


export const PAGES_ROUTES = RouterModule.forChild(pagesRoutes);
