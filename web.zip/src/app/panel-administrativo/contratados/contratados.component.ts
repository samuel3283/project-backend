import { Component, OnInit } from '@angular/core';
import {SelectItem} from 'primeng';
import {PanelService} from '../services/panel.service';
import {ActivatedRoute, Router} from '@angular/router';
import {ReclutadorService} from '../services/reclutador.service';
import * as moment from 'moment';
import {ConstantesUtil} from '../../util/constantesUtil';
import {ParametroEnvioContratado} from '../models/ParametroEnvioContratado';
import {ExportExcelService} from '../../service/export-excel.service';

@Component({
  selector: 'app-contratados',
    templateUrl: './contratados.component.html',
    styleUrls: ['./contratados.component.scss']
})
export class ContratadosComponent implements OnInit {

    PanelNuevos;
    statuses: any[];
    dataForExcel = [];

    loading = true;
    parametrosRequest: ParametroEnvioContratado;

    nuevos: any[];
    es: any;

    reclutadores: SelectItem[] = [];
    grupo: SelectItem[] = [];
    marca: SelectItem[] = [];
    puestos: SelectItem[] = [];
    fechaRegistro: Date[];
    nombreRecomendado: '';
    fechaInicio: '';
    FechaFin: '';


    data: any;
    paginador: any;
    tabNavegarNuevos = false;
    tabNavegarTodos = false;
    maxDate: Date = new Date();

    constructor(
        private panelService: PanelService,
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private reclutadorService: ReclutadorService,
        public ete: ExportExcelService) { }


    validarPath() {
        let arrayDeCadenas = window.location.pathname + '';
        if (arrayDeCadenas.startsWith('/admin/panel/nuevos')) {
            this.tabNavegarNuevos = true;
            this.tabNavegarTodos = false;
        } else if (arrayDeCadenas.startsWith('/admin/panel/todos')) {
            this.tabNavegarTodos = true;
            this.tabNavegarNuevos = false;
        } else {
            this.tabNavegarTodos = false;
            this.tabNavegarNuevos = false;
        }
    }

    ngOnInit(): void {
        this.validarPath();


        this.listReclutadores();
        this.listGrupo();
        this.listMarca();

        this.puestos = [
            { label: 'Técnico Farmaceútico (TF)', value: 2 },
            { label: 'Químico Farmaceútico (QF)', value: 1 },
        ];

        this.activatedRoute.paramMap.subscribe(params => {
            let page: number = +params.get('page');
            if (!page) {
                page = 0;
            } else if (page) {
                page = page - 1;
            }
            this.parametrosRequest = new ParametroEnvioContratado(['contratado'], [], [], [], [],  '', '', '', []);

            this.getFiltros(page);
        });


        this.statuses = [
            { label: 'Rechazado', value: 'Rechazado', style: 'unqualified' },
            { label: 'Contratado', value: 'Contratado', style: 'qualified' },
            { label: 'Nuevo', value: 1, style: 'new' },
            { label: 'En evaluacion', value: 'En evaluacion', style: 'negotiation' },
            { label: 'Cesado', value: 'Cesado', style: 'renewal' },
            { label: 'En proceso de contratación', value: 'En proceso de contratación', style: 'proposal' }
        ];

        this.es = {
            firstDayOfWeek: 1,
            dayNames: ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'],
            dayNamesShort: ['dom', 'lun', 'mar', 'mié', 'jue', 'vie', 'sáb'],
            dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
            monthNames: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'],
            monthNamesShort: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'],
            today: 'Hoy',
            clear: 'Borrar'
        };

    }



    exportToExcel(): void {
        this.panelService.getNuevos( this.parametrosRequest).subscribe(data => {
            this.data = data['source'];
            this.data.forEach((row: string) => {
                this.dataForExcel.push(Object.values(row));
            });
            const reportData = {
                title: 'Recomendados tabla Contratados',
                data: this.dataForExcel,
                headers: Object.keys(this.data[0])
            };

            this.ete.exportExcel(reportData);
        });
    }

    public getFiltros(page: number) {

        if (this.fechaRegistro != null && this.fechaRegistro.length === 2) {
            this.parametrosRequest.fechaInicio = moment(this.fechaRegistro[0]).format('YYYY-MM-DD');
            this.parametrosRequest.fechaFin = moment(this.fechaRegistro[1]).format('YYYY-MM-DD');
        }

        if (this.nombreRecomendado = null) {
            this.parametrosRequest.nombreRecomendado = this.nombreRecomendado;
        }

        this.panelService.getNuevos(this.parametrosRequest).subscribe(data => {
            this.nuevos = data['source'];
            this.paginador = data;
        });
    }

    listReclutadores() {
        this.reclutadorService.getReclutadores().subscribe((reclutadores: any) => {
            reclutadores.forEach(reclutador => this.reclutadores.push({ label: reclutador.nombreReclutador, value: reclutador.nombreReclutador }));
        });
    }

    listGrupo() {
        this.panelService.getGrupos().subscribe((grupos: any) => {
            grupos.forEach(grupo => this.grupo.push({label: grupo.nombre, value: grupo.nombre}));
        });
    }

    listMarca() {
        this.panelService.getMarcas().subscribe((marcas: any) => {
            marcas['parametroList'].forEach(marca => this.marca.push({label: marca.valor, value: marca.valor}));
            console.log(this.marca);
        });
    }

    initClickRecomendado(data: any) {
        sessionStorage.setItem('adminIdRcomendado', data.id);
        sessionStorage.setItem('adminIdColaborador', data.codigoColaborador);
        sessionStorage.setItem('adminEmailColaborador', data.emailColaborador);
        sessionStorage.setItem('adminIdRecomendacion', data.codigoRecomendacion);
        sessionStorage.setItem('adminDni', data.documentoRecomendado);
        sessionStorage.setItem('adminDiasFaltantes', data.diasFaltantes);
        sessionStorage.setItem('adminFechaPago', data.fechaPago);
        this.navegarEdicionRecomendados();
    }

    navegarEdicionRecomendados() {
        this.router.navigate([ConstantesUtil.paginaEditar]);
    }

    eliminarFiltros() {
        this.parametrosRequest.fechaInicio = null;
        this.parametrosRequest.fechaFin = null;
        this.fechaRegistro = null;
        this.parametrosRequest.estado = null;
        this.parametrosRequest.nombreRecomendado = null;
        this.parametrosRequest.idPuesto = null;
        this.parametrosRequest.idReclutador = null;
        this.parametrosRequest.idTipoBusqueda = null;
        this.parametrosRequest = new ParametroEnvioContratado([], [], [], [], [],  '', '', '', []);
        this.activatedRoute.paramMap.subscribe(params => {
            let page: number = +params.get('page');
            if (!page) {
                page = 0;
            } else if (page) {
                page = page - 1;
            }
            this.parametrosRequest = new ParametroEnvioContratado(['contratado'], [], [], [], [],  '', '', '', []);

            this.getFiltros(page);
        });
    }
    public onSortOrder(event) {
        this.listReclutadores();
    }

    initClickTodos() {
        this.navegarRecomendadoTodos();
    }

    initClickNuevos() {
        this.navegarRecomendadoNuevos();
    }

    navegarRecomendadoTodos() {
        this.router.navigate([ConstantesUtil.paginaTodos]);
    }
    navegarRecomendadoNuevos() {
        this.router.navigate([ConstantesUtil.paginaNuevos]);
    }
}
