import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {RecomendadoService} from 'src/app/service-landing/RecomendadoService';
import {ConstantesUtil} from 'src/app/util/constantesUtil';
import {ParametroService} from 'src/app/service-landing/ParametroService';
import {BlockUI, NgBlockUI} from 'ng-block-ui';
import {Referente} from 'src/app/model-landing/referente';
import {UbigeoService} from 'src/app/service-landing/UbigeoService';
import {MessageService, SelectItem} from 'primeng/api';
import {PreguntaService} from '../../service-landing/PreguntaService';
import {Pregunta} from '../../model-landing/pregunta';
import {PuestoService} from '../../service-landing/PuestoService';
import {CarreraService} from '../../service-landing/CarreraService';
import {RespuestaService} from '../services/respuesta.service';
import {CvService} from '../../service-landing/CvService';
import {LocalService} from '../services/local.service';
import {RecomendacionService} from '../services/recomendacion.service';
import {ParametroHistorial} from '../models/ParametroHistorial';
import {GruposService} from '../services/grupos.service';


@Component({
    selector: 'app-editar-recomendado',
    templateUrl: './editar-recomendado.html',
    styleUrls: ['./editar-recomendado.css'],
    providers: [MessageService]
    // encapsulation: ViewEncapsulation.None
})
export class EditarRecomendadoComponent implements OnInit {

    cars: SelectItem[];

    selectedCar1: string;

    selectedCar2: string = 'BMW';

    @ViewChild('inputFile') myInputVariable: ElementRef;

    @BlockUI() blockUI: NgBlockUI;

    referente: Referente;
    nombresCompletoRecomendado: string;
    listaParametro: any[];
    listaDistritos: any[];
    listaLocalEmpresa: any[];
    puestoRecomendado: string;
    listaParametroEstado: any[];
    listaParametroMotivoEstado: any[];
    listaTipoHorario: any[];
    estadoModel: any;
    puestoModel: any;
    horarioModel: any;
    carreraModel: any;
    descripcionModel: any;
    dniTextView: any;
    telefonoTextView: any;
    concatUbigeoTextView: any;
    fechaRegistro: Date;


    /*Datos Colaborador */
    nombreColaborador: string;
    cargoColaborador: string;
    emailColaborador: string;
    dniColaborador: string;
    telefonoColaborador: string;

    distritoSeleccionado: any;
    localContratoSeleccionado: any;
    nombreReferenteInicial: string;

    parametroSeleccionado: string;


    /*Input disable */
    nombreDisabled = false;
    apellidoDisabled = false;
    dniDisabled = false;
    distritoDisabled = false;
    telefonoDisabled = false;
    radioButtonDisabled = false;
    guardarDisabled = false;
    activarOpcionBoton = false;

    localEmpresaDisabled = false;

    listaPreguntasPadre: Pregunta[];
    listaPuesto: any[];
    listaCarrera: any[];
    listaDepartamento = [];
    historial: any[];
    idRecomendacion: string;

    opcionSeleccionado = '0'; // Iniciamos
    verSeleccion: string;

    idPuestoValidacion: string;

    /*Subida Archivo*/
    subirArchivoAll: File = null;
    nombreDelArchivo: string;
    extensionDelArchivo: string;
    statusSubida = false;
    statusMostrarCV = false;

    /*Item Contrato*/
    es: any;
    en: any;

    /*Status Datos Referido*/
    nombreStatusDatosPersonales = 'Ocultar';
    statusDatosPersonales = false;

    statusDatosPuesto = true;
    nombreStatusDatosPuesto = 'Ver';

    statusDatosContratado = true;
    nombreStatusDatosContrato = 'Ver';
    statusDatosContratadoContenido = true;

    statusDatosContratadoContenidoPremio = true;


    /*Parametro de historial*/
    documento: '';
    parametrosRequest: ParametroHistorial;

    statusMostrarEstado = true;
    statusMotivoEstado = true;
    divStatusEnEspera = true;
    divDerivacion = true;

    opcionSeleccionadoMotivo = '0';

    tipoEstado: any;
    nombreEstado: any;
    descripcionMotivo: any;

    estadoModelSeleccionado = '0';

    /*Status Contratado*/
    divRegistrarPremioContrato = true;
    divRegistrarTarjetaContratado = true;
    divContratoRecomendado = true;

    /*Monto por Puesto*/
    montoPorPuesto: any;
    dateContrato: any;
    dateFinContrato: any;
    //sumarFecha: any;
    sumarFecha: Date;

    nombreLocal: any;

    divStatusDerivado = true;

    gruposDataList: any[];
    grupoListaReclutadores: any[];

    dataDerivado: any;

    diasFaltantes: any;
    derivadoSuccess = false;
    enPeriodoContrataccionSuccess = false;

    estadoDisabled = false;

    contratoCambioCesado = false;

    constructor(private recomendadoService: RecomendadoService,
                private parametroService: ParametroService,
                private ubigeoService: UbigeoService,
                private messageService: MessageService,
                private preguntarService: PreguntaService,
                private puestoService: PuestoService,
                private carreraService: CarreraService,
                private respuestaService: RespuestaService,
                private cvService: CvService,
                private localService: LocalService,
                private recomendacionService: RecomendacionService,
                private gruposService: GruposService,
                private router: Router,
                private activatedRoute: ActivatedRoute) {
        this.referente = new Referente();
        this.referente.evento = 2;
        this.sumarFecha = new Date();
        this.sumarFecha.setDate(this.sumarFecha.getDate() + 90);

    }

    ngOnInit(): void {
        this.es = ConstantesUtil.validarEstado();
        const idRecomendado = sessionStorage.getItem('adminIdRcomendado');
        this.referente.idRecomendado = idRecomendado;
        this.obtenerListaParametroEstado();
        //this.iniciarDatosRecomendado(idRecomendado);
        this.initDesactivarVistas();
        this.activatedRoute.paramMap.subscribe(params => {
            let page: number = +params.get('page');
            if (!page) {
                page = 0;
            } else if (page) {
                page = page - 1;
            }
            this.parametrosRequest = new ParametroHistorial('');
            this.getHistorial();
        });
    }


    public getHistorial() {

        if (typeof this.documento != null) {
            const adminDni = sessionStorage.getItem('adminDni');
            this.parametrosRequest.documento = adminDni;
        }

        this.recomendadoService.getHistorial(this.parametrosRequest).subscribe(data => {
            this.historial = data['source'];
            console.log(this.documento);
        });
    }


    iniciarListaPreguntas() {
        const idPuesto = this.referente.idPuesto;
        const evento = this.referente.evento;
        this.blockUI.start('Procesando ...');
        this.preguntarService.obtenerListaPreguntaPorPuesto(idPuesto, evento).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaPreguntasPadre = data.preguntaList;
                this.iniciarListaRespuesta();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }


    validarDepartamentos() {
        for (const padre of this.listaPreguntasPadre) {
            const idTipoPregunta = padre.idTipoPregunta + '';
            if (idTipoPregunta === ConstantesUtil.tipo_pregunta_auto_complete) {
                const respuesta = padre.respuestaAutocomplete + '';
                for (const departamento of this.listaDepartamento) {
                    const departamentoId = departamento.id + '';
                    if (departamentoId === respuesta) {
                        this.opcionSeleccionado = departamento.id;
                        break;
                    }
                }
            }
        }
    }

    capturar(padre: any) {
        this.verSeleccion = this.opcionSeleccionado;
        const updateItem = this.listaPreguntasPadre.find(item => item.id === padre.id);
        const index = this.listaPreguntasPadre.indexOf(updateItem);
        this.listaPreguntasPadre[index].idRespuesta = this.opcionSeleccionado;
        this.listaPreguntasPadre[index].respuestaAutocomplete = {
            id: this.opcionSeleccionado,
            nombre: 'depa',
            estado: 'A'
        };
    }

    onClickHabilitar() {
        if (this.referente.estado === ConstantesUtil.tipo_estado_contratado) {
            /*this.guardarDisabled = false;
            this.activarOpcionBoton = true;
            this.initActivarDatosContrado();*/
        } else if (this.referente.estado === ConstantesUtil.tipo_estado_en_proceso_contratacion) {
            this.initActivarDatosContrado();
            this.guardarDisabled = false;
            this.activarOpcionBoton = true;
        } else {
            this.initActivarVistas();
        }
    }

    initActivarVistas() {
        this.nombreDisabled = false;
        this.apellidoDisabled = false;
        this.dniDisabled = false;
        this.distritoDisabled = false;
        this.telefonoDisabled = false;
        this.radioButtonDisabled = false;
        this.guardarDisabled = false;
        this.localEmpresaDisabled = false;
        this.activarOpcionBoton = true;
    }

    initDesactivarVistas() {
        this.nombreDisabled = true;
        this.apellidoDisabled = true;
        this.dniDisabled = true;
        this.distritoDisabled = true;
        this.telefonoDisabled = true;
        this.radioButtonDisabled = true;
        this.guardarDisabled = true;
        this.localEmpresaDisabled = true;
        this.activarOpcionBoton = false;
    }

    obtenerListaParametroFamiliar() {
        this.blockUI.start('Procesando ...');
        this.parametroService.obtenerListaParametro(ConstantesUtil.parametroTipoFamiliarRelacion).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaParametro = data.parametroList;
                this.iniciarBusquedaParametro();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    obtenerListaTipoHorario() {
        this.blockUI.start('Procesando ...');
        this.parametroService.obtenerListaParametro(ConstantesUtil.parametroTipoHorario).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaTipoHorario = data.parametroList;
                this.iniciarBusquedaHorario();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    iniciarBusquedaHorario() {
        for (let i = 0; i < this.listaTipoHorario.length; i++) {
            const parametro = this.listaTipoHorario[i];
            const idHorario = parametro.id + '';
            if (idHorario === this.referente.idHorario) {
                this.horarioModel = this.listaTipoHorario[i];
                return;
            }
        }
    }

    obtenerListaParametroEstado() {
        this.blockUI.start('Procesando ...');
        this.parametroService.obtenerListaParametro(ConstantesUtil.parametroTipoEstado).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaParametroEstado = data.parametroList;
                this.iniciarDatosRecomendado(this.referente.idRecomendado);
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    iniciarBusquedaParametroEstado() {
        for (let i = 0; i < this.listaParametroEstado.length; i++) {
            const parametro = this.listaParametroEstado[i];
            if (parametro.descripcion === this.referente.estado) {
                this.estadoModelSeleccionado = this.listaParametroEstado[i].descripcion;
                return;
            }
        }
    }

    onClickEstado() {

        this.opcionSeleccionadoMotivo = '0';
        this.referente.idMotivo = '0';
        this.nombreEstado = this.estadoModelSeleccionado;
        if (this.nombreEstado === ConstantesUtil.tipo_estado_en_espera) {
            this.mostrarComponentesMotivoEnEspera();
            this.iniciarListaEnEspera(ConstantesUtil.parametroTipoEnEspera);
            this.tipoEstado = 'En espera';
            /*Desactivando Botones Contrato*/
            this.desactivarBotonesRegistroContrato();
            this.ocultarDivContratadoRecomendado();
            //--------
            this.divStatusDerivado = true;
        } else if (this.nombreEstado === ConstantesUtil.tipo_estado_rechazado) {
            this.mostrarComponentesMotivoEnEspera();
            this.iniciarListaEnEspera(ConstantesUtil.parametroTipoRechazado);
            this.tipoEstado = 'Rechazado';
            /*Desactivando Botones Contrato*/
            this.desactivarBotonesRegistroContrato();
            this.ocultarDivContratadoRecomendado();
            //----------
            this.divStatusDerivado = true;
        } else if (this.nombreEstado === ConstantesUtil.tipo_estado_contratado) {
            /*this.ocultarComponentesMotivoEnEspera();
            this.divRegistrarPremioContrato = false;
            this.divRegistrarTarjetaContratado = true;*/

            alert('Primero debe llenar los campos de proceso contratación');
            this.obtenerListaParametroEstado();

        } else if (this.nombreEstado === ConstantesUtil.tipo_estado_derivado) {
            this.tipoEstado = 'derivado';
            this.divStatusDerivado = false;
            this.divStatusEnEspera = true;
            this.iniciarServicioObtenerReclutadoresPorGrupos();
            //this.mostrarDerivacion();
            //alert('derivado');
        } else {
            this.ocultarComponentesMotivoEnEspera();
            this.statusMotivoEstado = true;
            /*Desactivando Botones Contrato*/
            this.desactivarBotonesRegistroContrato();
            this.ocultarDivContratadoRecomendado();
            this.iniciatServicioCambioEstadoRecomendado(this.nombreEstado);
        }
    }

    iniciarServicioObtenerReclutadoresPorGrupos() {
        this.blockUI.start('Procesando ...');
        this.gruposService.iniciarServicioObtenerReclutadoresPorGrupos(this.referente.idPuesto).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                //this.grupoListaReclutadores = data.gruposDataList;
                this.gruposDataList = data.gruposDataList;
                /*this.grupoListaReclutadores = [];

                data.gruposDataList.forEach((t, i) => {
                    this.grupoListaReclutadores.push(data.gruposDataList[i]);
                });*/

                //this.grupoListaReclutadores = data.gruposDataList;
                //this.iniciarBusquedaParametro();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    selectedCountryAdvanced: any[];

    onCompletarGrupo(event) {
        let filtered: any[] = [];
        let query = event.query;
        for (let i = 0; i < this.gruposDataList.length; i++) {
            let country = this.gruposDataList[i];
            if (country.nombreReclutador.toLowerCase().indexOf(query.toLowerCase()) == 0) {
                filtered.push(country);
            }
        }
        this.grupoListaReclutadores = filtered;
    }

    mostrarDivContratadoRecomendado() {
        this.divContratoRecomendado = false;
    }

    ocultarDivContratadoRecomendado() {
        this.divContratoRecomendado = true;
    }

    mostrarDerivacion() {
        this.divDerivacion = false;
    }

    ocultarDerivacion() {
        this.divDerivacion = true;
    }


    desactivarBotonesRegistroContrato() {
        this.divRegistrarTarjetaContratado = true;
        this.divRegistrarPremioContrato = true;
    }

    ocultarComponentesMotivoEnEspera() {
        this.statusMostrarEstado = true;
        this.statusMotivoEstado = true;
        this.divStatusEnEspera = true;
    }

    mostrarComponentesMotivoEnEspera() {
        this.statusMostrarEstado = false;
        this.statusMotivoEstado = false;
        this.divStatusEnEspera = false;
    }

    iniciarListaEnEspera(parametroBuscar: any) {
        this.blockUI.start('Procesando ...');
        this.parametroService.obtenerListaParametro(parametroBuscar).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaParametroMotivoEstado = data.parametroList;
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    capturarMotivo() {
        this.referente.idMotivo = this.opcionSeleccionadoMotivo;
    }

    onClickPuesto(event) {
        const nombreEstado = event.value.descripcion;
        this.referente.idPuesto = event.value.id;
        this.iniciarListaCarreraPorPuesto(this.referente.idPuesto);
        this.iniciarListaPreguntas();
    }

    onClickCarrera(event) {
        this.referente.idCarrera = event.value.id;
    }

    onClickHorario(event) {
        this.referente.idHorario = event.value.id;
    }

    iniciatServicioCambioEstadoRecomendado(nombreEstado: any) {
        this.blockUI.start('Procesando ...');
        const idRecomendacion = sessionStorage.getItem('adminIdRecomendacion');
        const idRecomendado = sessionStorage.getItem('adminIdRcomendado');
        const idColaborador = sessionStorage.getItem('adminIdColaborador');
        const emailColaborador = sessionStorage.getItem('adminEmailColaborador');

        let recomendadoEstado;
        if (this.derivadoSuccess) {
            recomendadoEstado = {
                idRecomendado: idRecomendado,
                estadoRecomendado: nombreEstado,
                idColaborador: idColaborador,
                emailColaborador: emailColaborador,
                idMotivo: this.referente.idMotivo,
                idRecomendacion: idRecomendacion,
                numeroTarjeta: this.referente.numeroTarjeta,
                idPuesto: this.referente.idPuesto,

                idReclutador: this.dataDerivado.idReclutador,
                nombreReclutador: this.dataDerivado.nombreReclutador,
                idGrupo: this.dataDerivado.idGrupo,
                nombreGrupo: this.dataDerivado.nombreGrupo,
                marcaGrupo: this.dataDerivado.marcaGrupo
            };
        } else {
            recomendadoEstado = {
                idRecomendado: idRecomendado,
                estadoRecomendado: nombreEstado,
                idColaborador: idColaborador,
                emailColaborador: emailColaborador,
                idMotivo: this.referente.idMotivo,
                idRecomendacion: idRecomendacion,
                numeroTarjeta: this.referente.numeroTarjeta,
                idPuesto: this.referente.idPuesto
            };
        }


        this.recomendacionService.actualizarEstadoRecomendado(recomendadoEstado).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                alert('Estado Actualizado Correctamente');
                if (this.derivadoSuccess) {
                    this.router.navigate([ConstantesUtil.paginaAdministrativo]);
                    this.blockUI.stop();
                    return;
                }
                if (this.contratoCambioCesado) {
                    this.listaParametroEstado = null;
                    this.obtenerListaParametroEstado();
                    this.blockUI.stop();
                    return;
                }

                this.iniciarDatosRecomendado(this.referente.idRecomendado);
                this.blockUI.stop();
            } else {
                alert('OCURRIO ALGUN PROBLEMA ' + data.mensaje);
                this.blockUI.stop();
            }
        });
    }

    iniciarBusquedaParametro() {
        for (const parametro of this.listaParametro) {
            if (parametro.id === this.referente.idTipoParametro) {
                this.parametroSeleccionado = parametro.valor;
                return;
            }
        }
    }

    initWacthDistrito(event) {
        const nombreDistrito = event.query;
        if (nombreDistrito.length > 2) {
            this.iniciarBuscarDistritoPorNombre(nombreDistrito);
        } else {
            this.initLimpiarReferenteDistrito();
        }
    }

    iniciarBuscarDistritoPorNombre(nombreDistrito: string) {
        this.ubigeoService.buscarDistritoPorNombre(nombreDistrito).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaDistritos = data.distritoDtoList;
            }
        });
    }

    initLimpiarReferenteDistrito() {
        this.referente.nombreDistrito = null;
        this.referente.idDistrito = null;
        this.referente.idDepartamento = null;
        this.referente.idProvincia = null;
    }

    onSelectedParametro(parametro: any) {
        this.referente.idTipoParametro = parametro.id;
    }

    iniciarDatosRecomendado(idRecomendado: any) {
        const idRecomendacion = sessionStorage.getItem('adminIdRecomendacion');
        this.recomendadoService.obtenerRecomendadoPorId(idRecomendado, idRecomendacion).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {

                this.referente.estado = data.dataRecoRefeResponse.estadoRecomendado;
                //this.obtenerListaParametroEstado();
                this.iniciarBusquedaParametroEstado();

                //this.dateContrato = data.dataRecoRefeResponse.dateContrato;//.slice(0,10);
                this.dateContrato = data.dataRecoRefeResponse.dateNumeroTarjetaRegistro;

                const dataRecomendado = data.dataRecoRefeResponse.nombreRecomendado;
                this.nombresCompletoRecomendado = dataRecomendado + ' ' + data.dataRecoRefeResponse.apellidoRecomendado;
                this.iniciarValidacionPuesto(data.dataRecoRefeResponse.idPuestoRecomendado);
                //Datos Colaborador
                this.nombreColaborador = data.dataRecoRefeResponse.nombreColaborador + ' ' + data.dataRecoRefeResponse.apellidosColaborador;
                this.dniColaborador = '(DNI ' + '' + data.dataRecoRefeResponse.dniColaborador + ')';
                this.cargoColaborador = data.dataRecoRefeResponse.cargoColaborador + '(' + data.dataRecoRefeResponse.localColaborador + ')';
                this.telefonoColaborador = data.dataRecoRefeResponse.telefonoColaborador;
                this.emailColaborador = data.dataRecoRefeResponse.emailColaborador;
                //Instancia Referente
                this.referente.idTipoParametro = data.dataRecoRefeResponse.idRelacionRecomendado;
                this.referente.idPuesto = data.dataRecoRefeResponse.idPuestoRecomendado;
                this.idPuestoValidacion = data.dataRecoRefeResponse.idPuestoRecomendado;
                this.referente.nombres = data.dataRecoRefeResponse.nombreRecomendado;
                this.referente.apellidos = data.dataRecoRefeResponse.apellidoRecomendado;
                const dataReferente = data.dataRecoRefeResponse.nombreRecomendado + ' ' + data.dataRecoRefeResponse.apellidoRecomendado;
                this.nombreReferenteInicial = '¿ ' + dataReferente + ' ';
                this.referente.dni = data.dataRecoRefeResponse.dniRecomendado;
                this.referente.telefono = data.dataRecoRefeResponse.telefonoRecomendado;
                this.referente.concatUbigeo = data.dataRecoRefeResponse.nombreUbiRecomendado;

                this.referente.nombreDistrito = data.dataRecoRefeResponse.nombreUbiRecomendado;
                this.referente.idDistrito = data.dataRecoRefeResponse.idDistrito;

                this.referente.idDepartamento = data.dataRecoRefeResponse.idDepartamento;
                this.referente.idProvincia = data.dataRecoRefeResponse.idProvincia;
                this.referente.concatUbigeo = data.dataRecoRefeResponse.nombreUbiRecomendado;


                this.validarEstado();
                this.dniTextView = data.dataRecoRefeResponse.dniRecomendado;
                this.telefonoTextView = data.dataRecoRefeResponse.telefonoRecomendado;
                this.concatUbigeoTextView = data.dataRecoRefeResponse.nombreUbiRecomendado;
                this.referente.idCarrera = data.dataRecoRefeResponse.idCarreraRecomendado;
                this.idRecomendacion = data.dataRecoRefeResponse.idRecomendacion;
                this.referente.idRecomendacion = data.dataRecoRefeResponse.idRecomendacion;

                this.referente.zonaPreferencia = data.dataRecoRefeResponse.zonaPreferencia;
                this.referente.idHorario = data.dataRecoRefeResponse.idHorario;
                this.referente.observacionesPuesto = data.dataRecoRefeResponse.observacionesPuesto;

                this.referente.cvRecomendado = data.dataRecoRefeResponse.cvRecomendado;
                this.validarParametroMotivo(data.dataRecoRefeResponse.descripcionMotivo);


                //Datos contrato
                this.referente.observacionesContrato = data.dataRecoRefeResponse.observacionesContrato;

                const dateContrato = data.dataRecoRefeResponse.dateContrato !== null ? new Date(data.dataRecoRefeResponse.dateContrato) : null;

                this.referente.dateContrato = dateContrato;

                this.referente.idLocalContrato = data.dataRecoRefeResponse.idLocalContrato;

                this.validacionIdLocal();

                this.validarMuestraCV();
                //this.obtenerListaParametroEstado();

                this.obtenerListaParametroFamiliar();
                this.obtenerListaTipoHorario();

                this.obtenerListaPuesto();
                this.iniciarListaCarreraPorPuesto(this.referente.idPuesto);
                this.iniciarListaDepartamentos();

                this.validarNumeroTarjeta(data.dataRecoRefeResponse.numeroTarjeta);

                this.distritoSeleccionado = {
                    idDistrito: this.referente.idDistrito,
                    nombreDistrito: this.referente.concatUbigeo,
                    idProvincia: this.referente.idProvincia,
                    idDepartamento: this.referente.idDepartamento,
                    nombreProvincia: this.referente.concatUbigeo,
                    concatDistrito: this.referente.concatUbigeo,
                    nombreDepartamento: this.referente.concatUbigeo
                };

                console.log('No existe REcomendado ');
            }
        });
    }

    validarNumeroTarjeta(numeroTarjeta: any) {
        if (numeroTarjeta == null) {
            console.log('Vacio ');
            //this.divContratoRecomendado= true;
            //this.divRegistrarPremioContrato = true;
        } else {
            this.divRegistrarPremioContrato = true;
            this.divContratoRecomendado = false;
        }
    }

    validarMuestraCV() {
        if (this.referente.cvRecomendado != null) {
            this.statusMostrarCV = true;
        } else {
            this.statusMostrarCV = false;
        }
    }

    iniciarListaRespuesta() {
        this.respuestaService.obtenerListaRespuesta(this.idRecomendacion).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaPreguntasPadre.forEach((padre, index) => {
                    data.respuestaList.forEach((hijoRespuesta, indexHijo) => {
                        const idPregunta = padre.id + '';
                        if (idPregunta === hijoRespuesta.idPregunta) {
                            padre.opcionRespuestas.forEach((hijo, index3) => {
                                data.respuestaList.forEach((respuesta, index4) => {
                                    const tipoPregunta = hijo.idTipoPregunta + '';
                                    if (tipoPregunta === ConstantesUtil.tipo_pregunta_radio_button) {
                                        const idRespuesta = hijo.id + '';
                                        if (idRespuesta === respuesta.idRespuesta) {
                                            padre.respuestaEnunciado = respuesta.enunciadoRespuesta;
                                            padre.idRespuesta = respuesta.idRespuesta;
                                        }
                                    } else {
                                        padre.idRespuesta = respuesta.idRespuesta;
                                        padre.respuestaAutocomplete = respuesta.idRespuesta;
                                    }
                                });
                            });
                        }
                    });
                });
                this.validarDepartamentos();
            }
        });
    }

    selectOpcionesPreguntas(hijo: any, padre: any) {
        const updateItem = this.listaPreguntasPadre.find(item => item.id === padre.id);
        const index = this.listaPreguntasPadre.indexOf(updateItem);
        this.listaPreguntasPadre[index].idRespuesta = hijo.id;
        this.listaPreguntasPadre[index].respuestaEnunciado = hijo.enunciado;
        console.log(this.listaPreguntasPadre);

    }

    iniciarListaDepartamentos() {
        this.ubigeoService.buscarDepartamentoCritico().subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaDepartamento = data.departamentoList;
                this.iniciarListaPreguntas();
            }
        });
    }

    iniciarListaCarreraPorPuesto(idPuesto: string) {
        this.carreraService.obtenerCarreraPorPuesto(idPuesto).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaCarrera = data.carreraList;
                this.iniciarBusquesdaCarrera();
            }
        });
    }

    obtenerListaPuesto() {
        this.blockUI.start('Procesando ...');
        this.puestoService.obtenerListaPuesto().subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaPuesto = data.puestoListaResponseList;
                this.iniciarBusquedaPuesto();
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    iniciarBusquesdaCarrera() {
        for (let i = 0; i < this.listaCarrera.length; i++) {
            const carrera = this.listaCarrera[i];
            const idCarrera = carrera.id + '';
            if (idCarrera === this.referente.idCarrera) {
                this.carreraModel = this.listaCarrera[i];
                return;
            }
        }
    }

    iniciarBusquedaPuesto() {

        for (let i = 0; i < this.listaPuesto.length; i++) {
            const puesto = this.listaPuesto[i];
            const idPuesto = puesto.id + '';
            if (idPuesto === this.referente.idPuesto) {
                this.puestoModel = this.listaPuesto[i];
                return;
            }
        }
    }

    iniciarValidacionPuesto(idPuestoRecomendado: string) {
        if (idPuestoRecomendado === '1') {
            this.montoPorPuesto = 'S./300';
            this.puestoRecomendado = 'Químico farmacéutico';
        } else if (idPuestoRecomendado === '2') {
            this.montoPorPuesto = 'S./200';
            this.puestoRecomendado = 'Técnico farmacéutico';
        }
    }

    numeroValidar(event) {
        const charCode = (event.which) ? event.which : event.keyCode;
        if (charCode > 31 && (charCode < 48 || charCode > 57)) {
            return false;
        }
        return true;
    }

    onClickEditar() {
        this.initValidarCampos();
        for (const padre of this.listaPreguntasPadre) {
            if (padre.idRespuesta == null) {
                const tipoPreguntaPadre = padre.idTipoPregunta + '';
                if (tipoPreguntaPadre === '1') {/*Radio Button*/
                    const index = this.listaPreguntasPadre.indexOf(padre);
                    const sum = [index + 1];
                    alert(' Te falta completar la pregunta  ' + sum);
                    return;
                }
                if (tipoPreguntaPadre === '2') {/*Auto COmplete*/
                    const index = this.listaPreguntasPadre.indexOf(padre);
                    const sum = [index + 1];
                    alert(' Te falta seleccionar algun departamento  ' + sum);
                    return;
                }
            }
        }
        this.referente.listaRespuesta = [];
        for (const padre of this.listaPreguntasPadre) {
            this.referente.listaRespuesta.push({
                idOpcionRespuesta: padre.idRespuesta + '',
                idPregunta: padre.id + '',
                respuestaEnunciado: padre.respuestaEnunciado + '',
                respuestaAutocomplete: padre.respuestaAutocomplete + ''
            });
        }
        this.initActualizaRecomendado();
    }

    initValidarCampos() {
        if (this.referente.nombres === '' || this.referente.nombres === null || this.referente.nombres === undefined) {
            alert('Complete nombre referente');
            return;
        }
        if (this.referente.apellidos === '' || this.referente.apellidos === null || this.referente.apellidos === undefined) {
            alert('Complete apellidos referente');
            return;
        }
        if (this.referente.dni === '' || this.referente.dni === null || this.referente.dni === undefined) {
            alert('Complete dni referente');
            return;
        }
        if (this.referente.dni.length < 8) {
            alert('Coloque el número dni correcto');
            return;
        }
        if (this.referente.telefono === '' || this.referente.telefono === null || this.referente.telefono === undefined) {
            alert('Complete telefono referente');
            return;
        }
        if (this.referente.telefono.length < 7) {
            alert('Coloque el número telefono correcto');
            return;
        }
        if (this.referente.nombreDistrito === '' || this.referente.nombreDistrito === null || this.referente.nombreDistrito === undefined) {
            alert('Complete distrito referente');
            return;
        }
        if (this.referente.idTipoParametro === '' || this.referente.idTipoParametro === null || this.referente.idTipoParametro === undefined) {
            alert('Complete tipo relacion del referente');
            return;
        }
    }

    initActualizaRecomendado() {

        this.blockUI.start('Procesando ...');
        const idColaborador = sessionStorage.getItem('adminIdColaborador');
        this.referente.idColaborador = idColaborador;
        this.recomendadoService.actualizarRecomendado(this.referente).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.initValidarGuardarCamposProcesoContrato();
                if (this.nombreDelArchivo != null) {
                    this.cvService.actualizarCvAdmin(this.subirArchivoAll, this.referente.idRecomendado).subscribe(data => {
                        this.iniciarDatosRecomendado(this.referente.idRecomendado);
                        this.statusSubida = false;
                        this.subirArchivoAll = null;
                        this.myInputVariable.nativeElement.value = '';
                        this.nombreDelArchivo = null;
                        alert('Actualizo Correctamente Recomendado ');
                        this.blockUI.stop();
                    });
                } else {
                    this.iniciarDatosRecomendado(this.referente.idRecomendado);
                    alert('Actualizo Correctamente Recomendado');
                    this.blockUI.stop();
                }

            } else {
                this.blockUI.stop();
            }
        });
    }

    initValidarGuardarCamposProcesoContrato() {
        if (this.referente.idLocalContrato != null && this.referente.dateContrato != null) {
            this.router.navigate([ConstantesUtil.paginaContratados]);
            return;
        }
    }

    onSelectDistrito(event) {
        this.referente.idDistrito = event.idDistrito;
        this.referente.idDepartamento = event.idDepartamento;
        this.referente.idProvincia = event.idProvincia;
        this.referente.nombreDistrito = event.nombreDistrito;
        this.referente.nombreDepartamento = event.nombreDepartamento;
        this.referente.nombreProvincia = event.nombreProvincia;
        this.referente.concatUbigeo = event.nombreDistrito + ',' + event.nombreProvincia + ',' + event.nombreDepartamento;
    }

    onClickCancelar() {
        this.navegadorListadoReferidos();
    }

    navegadorListadoReferidos() {
        this.router.navigate([ConstantesUtil.paginaAdministrativo]);
    }

    showMsgs(tipoMsg, titulo, msg) {
        this.messageService.add({severity: tipoMsg, summary: titulo, detail: msg});
    }

    subirArchivo(event) {
        this.subirArchivoAll = event.target.files.item(0);
        this.nombreDelArchivo = this.subirArchivoAll.name;
        if (this.nombreDelArchivo != null) {
            if (this.subirArchivoAll.name.endsWith('jpg') ||
                this.subirArchivoAll.name.endsWith('png') ||
                this.subirArchivoAll.name.endsWith('doc') ||
                this.subirArchivoAll.name.endsWith('docx') ||
                this.subirArchivoAll.name.endsWith('pdf') ||
                this.subirArchivoAll.name.endsWith('JPG') ||
                this.subirArchivoAll.name.endsWith('PNG') ||
                this.subirArchivoAll.name.endsWith('DOC') ||
                this.subirArchivoAll.name.endsWith('DOCX') ||
                this.subirArchivoAll.name.endsWith('DOCX') ||
                this.subirArchivoAll.name.endsWith('PNG')
            ) {
                this.statusSubida = true;
                this.extensionDelArchivo = this.subirArchivoAll.name.split('.').pop();
            } else {
                this.statusSubida = false;
                this.subirArchivoAll = null;
                this.myInputVariable.nativeElement.value = '';
                alert('No se permite tipo archivo, intente con otro');
            }
        }
    }

    onClickLimpiarFile() {
        this.myInputVariable.nativeElement.value = '';
        this.subirArchivoAll = null;
        this.statusSubida = false;
    }

    onClickDescargarCV() {
        window.open(this.referente.cvRecomendado);
    }


    validarEstado() {
        this.activarOpcionBoton = false;
        if (this.referente.estado === ConstantesUtil.tipo_estado_contratado) {

            this.statusDatosContratado = false;
            this.statusDatosPersonales = true;
            this.statusDatosContratadoContenido = true;
            this.nombreStatusDatosPersonales = 'Ver';
            this.nombreStatusDatosContrato = 'Ocultar';
            this.es = ConstantesUtil.validarEstado();
            this.statusDatosContratadoContenidoPremio = false;
            const diasFaltantes = sessionStorage.getItem('adminDiasFaltantes');
            this.diasFaltantes = 'Dias faltantes ' + diasFaltantes;
            const fechaPago = sessionStorage.getItem('adminFechaPago');
            this.dateFinContrato = fechaPago;


            var numberValueDiasFaltantes = Number(diasFaltantes);
            /* if (diasFaltantes === '0') {
                 this.ocultarComponentesMotivoEnEspera();
                 this.divRegistrarPremioContrato = false;
                 this.divRegistrarTarjetaContratado = true;
             }*/

            //this.estadoDisabled = true;

            if (numberValueDiasFaltantes <= 0) {
                this.diasFaltantes = 'Cumplido';
                this.ocultarComponentesMotivoEnEspera();
                this.divRegistrarPremioContrato = false;
                this.divRegistrarTarjetaContratado = true;
            }
            this.initValidarEstadoEnContrado();
        } else if (this.referente.estado === ConstantesUtil.tipo_estado_en_proceso_contratacion) {
            this.statusDatosContratadoContenido = false;
            this.statusDatosContratado = false;
            this.statusDatosPersonales = true;
            this.nombreStatusDatosPersonales = 'Ver';
            this.es = ConstantesUtil.validarEstado();
            this.initDesactivarDatosPuesto();
            this.initDesactivarDatosContrado();
            this.estadoDisabled = false;
        } else {
            this.statusDatosPersonales = false;
            this.nombreStatusDatosPersonales = 'Ocultar';
            this.statusDatosContratado = true;
            this.initDesactivarVistas();
            this.estadoDisabled = false;
        }
    }

    initValidarEstadoEnContrado() {
        if (this.estadoModelSeleccionado === 'Contratado') {
            this.contratoCambioCesado = true;
            for (let i = 0; i < this.listaParametroEstado.length; i++) {
                const parametro = this.listaParametroEstado[i];

                if (parametro.id == 10) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                } else if (parametro.id == 11) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                } else if (parametro.id == 12) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                }
                /*else if (parametro.id == 13) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                }*/
                else if (parametro.id == 14) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                } else if (parametro.id == 15) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                } else if (parametro.id == 16) {
                    this.listaParametroEstado.splice(this.listaParametroEstado.indexOf(parametro), 1);
                    this.initValidarEstadoEnContrado();
                    break;
                }

                //alert('parametro.id '+ parametro.id);
            }
        } else {
            this.contratoCambioCesado = false;
        }

    }


    onClickVerDatosPersonales() {
        if (this.statusDatosPersonales) {
            this.nombreStatusDatosPersonales = 'Ocultar';
            this.statusDatosPersonales = false;
        } else {
            this.nombreStatusDatosPersonales = 'Ver';
            this.statusDatosPersonales = true;
        }
    }

    onClickVerDatosPuesto() {
        if (this.statusDatosPuesto) {
            this.nombreStatusDatosPuesto = 'Ocultar';
            this.statusDatosPuesto = false;
        } else {
            this.nombreStatusDatosPuesto = 'Ver';
            this.statusDatosPuesto = true;
        }
    }

    onClickVerDatosContrato() {
        if (this.referente.estado === ConstantesUtil.tipo_estado_contratado) {

            return;
        }
        if (this.statusDatosContratadoContenido) {
            this.nombreStatusDatosContrato = 'Ocultar';
            this.statusDatosContratadoContenido = false;
        } else {
            this.nombreStatusDatosContrato = 'Ver';
            this.statusDatosContratadoContenido = true;
        }
    }


    onSelectLocalEmpresa(event) {
        this.referente.idLocalContrato = event.id;
    }

    initWacthLocalEmpresa(event) {
        const nombreLocal = event.query;
        if (nombreLocal.length > 2) {
            this.iniciarServicioObtenerLocalesContrato(nombreLocal);
        }
    }


    iniciarServicioObtenerLocalesContrato(nombreLocal: any) {
        this.blockUI.start('Procesando ...');
        this.localService.obtenerListaLocalesPorNombre(nombreLocal).subscribe(data => {
            if (data.codigo === ConstantesUtil.codMsjOk) {
                this.listaLocalEmpresa = data.localList;
                this.blockUI.stop();
            } else {
                this.blockUI.stop();
            }
        });
    }

    validacionIdLocal() {
        if (this.referente.idLocalContrato === '0') {
            console.log('vacio');
        } else {
            this.blockUI.start('Procesando ...');
            this.localService.obtenerLocalId(this.referente.idLocalContrato).subscribe(data => {
                try {
                    this.localContratoSeleccionado = {
                        descripcion: data.nombreBotica,
                        id: data.id,
                        concatLocalMarca: data.concatLocalMarca,
                    };
                    this.nombreLocal = this.localContratoSeleccionado.concatLocalMarca;
                    this.blockUI.stop();
                } catch (e) {
                    this.blockUI.stop();
                }
            });
        }

    }

    initDesactivarDatosPuesto() {
        this.nombreDisabled = true;
        this.apellidoDisabled = true;
        this.dniDisabled = true;
        this.distritoDisabled = true;
        this.telefonoDisabled = true;
        this.radioButtonDisabled = true;
    }

    initActivarDatosContrado() {
        this.localEmpresaDisabled = false;
    }

    initDesactivarDatosContrado() {
        this.localEmpresaDisabled = true;
    }

    onClickAceptoMotivoEstado() {
        if (this.referente.idMotivo === '0') {
            alert('Seleccione un motivo');
            return;
        }
        alert('Iniciar Cambio de Estado ');
        this.iniciatServicioCambioEstadoRecomendado(this.nombreEstado);
        this.ocultarComponentesMotivoEnEspera();

    }

    onClickCancelarMotivoEstado() {
        this.divStatusEnEspera = true;
        this.statusMostrarEstado = true;
        this.iniciarBusquedaParametroEstado();
        alert('Cancelo');
    }

    validarParametroMotivo(descripcionMotivo: any) {
        if (descripcionMotivo === null) {
            this.descripcionMotivo = '';
            return;
        }
        this.descripcionMotivo = descripcionMotivo;
    }

    onClickRegistrarPremio() {
        this.divRegistrarPremioContrato = true;
        this.divRegistrarTarjetaContratado = false;
    }

    onClickCheckRegistrarPremio() {
        if (this.referente.numeroTarjeta === '' || this.referente.numeroTarjeta === null || this.referente.numeroTarjeta === undefined) {
            alert('Ingrese el número de tarjeta');
            return;
        }
        this.nombreEstado = 'Contratado';
        this.iniciatServicioCambioEstadoRecomendado(this.nombreEstado);
    }

    onClickCloseRegistrarPremio() {
        this.divRegistrarTarjetaContratado = true;
        this.divRegistrarPremioContrato = true;
        this.iniciarBusquedaParametroEstado();
        this.divRegistrarPremioContrato = false;
    }


    onClickCancelarDerivador() {
        this.dataDerivado = null;
        this.divStatusDerivado = true;
        this.derivadoSuccess = false;
        this.iniciarBusquedaParametroEstado();
    }


    onClickAceptoDerivados() {
        if (this.dataDerivado === '' || this.dataDerivado === null || this.dataDerivado === undefined) {
            alert('Elija reclutador a derivar');
            return;
        }
        this.derivadoSuccess = true;
        this.iniciatServicioCambioEstadoRecomendado(this.nombreEstado);
    }

    onSelectReclutador(event: any) {
        this.dataDerivado = event;
    }
}
