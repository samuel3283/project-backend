import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {ConstantesUtil} from '../../util/constantesUtil';
import {environment} from 'src/environments/environment';

@Component({
    selector: 'app-inicio',
    templateUrl: './inicio.component.html',
    styleUrls: ['./inicio.component.css']
})
export class InicioComponent implements OnInit {

    activarPrimerTab: boolean = false;
    activarSegundoTab: boolean = false;
    activarColorReferidos = false;
    activarColorConfiguracion = false;

    statusPrimerNull = false;


    constructor(private router: Router) {

    }

    async initValidarSessionStorage() {
        const rolUsuario = sessionStorage.getItem('rolUsuario');
        this.activarColorReferidos = true;
        if (rolUsuario === ConstantesUtil.ROL_USUARIO_ADMIN) {
            this.activarSegundoTab = true;
        } else {
            this.activarSegundoTab = false;
        }
    }

    iniciarReclutadores() {
        this.activarColorConfiguracion = true;
        this.activarColorReferidos = false;
        this.router.navigate([ConstantesUtil.paginaReclutadores]);
    }

    ngOnInit() {
        this.initValidarSessionStorage();
    }

    navegadorListadoReferidos() {
        this.activarColorConfiguracion = false;
        this.activarColorReferidos = true;
        this.router.navigate([ConstantesUtil.paginaAdministrativo]);
    }

    onClickReferidos() {
        this.navegadorListadoReferidos();
    }

    cerrarSesion() {
        sessionStorage.clear();
        location.href = environment.urlPortal;
    }


}
