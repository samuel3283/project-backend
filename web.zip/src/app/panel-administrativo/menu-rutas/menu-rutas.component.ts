import { Component, OnInit } from '@angular/core';
import {ConstantesUtil} from '../../util/constantesUtil';
import {Router} from '@angular/router';

@Component({
  selector: 'app-menu-rutas',
  template: `
      <div class="ui-g form-group">
          <div class="ui-g-1.6">
              <h5 class="card-title mr-3"><a (click)="initClickTodos()">Todos</a></h5>
              <hr *ngIf="router.url.includes('/admin/panel/todos')"
                  style="width:50px;text-align:left;margin-left:0;height:3px;border-width:0;color:red;background-color:red;margin-top:0.9rem">
          </div>
          <div class="ui-g-1.6">
              <h5 class="card-title mr-3"><a (click)="initClickNuevos()">Nuevos</a></h5>
              <hr *ngIf="router.url.includes('/admin/panel/nuevos')"
                  style="width:50px;text-align:left;margin-left:0;height:3px;border-width:0;color:red;background-color:red;margin-top:0.9rem">
          </div>
          <div class="ui-g-1.6">
              <h5 class="card-title mr-3"><a (click)="initClickEvaluacion()">En evaluación</a></h5>
              <hr *ngIf="router.url.includes('/admin/panel/evaluacion')"
                  style="width:100px;text-align:left;margin-left:0;height:3px;border-width:0;color:red;background-color:red;margin-top:0.9rem">
          </div>
          <div class="ui-g-1.6">
              <h5 class="card-title mr-3"><a (click)="initClickContratados()">Contratados</a></h5>
              <hr *ngIf="router.url.includes('/admin/panel/contratados')"
                  style="width:100px;text-align:left;margin-left:0;height:3px;border-width:0;color:red;background-color:red;margin-top:0.9rem">
          </div>
      </div>
  `,
    styleUrls: ['./menu-rutas.component.scss']
})
export class MenuRutasComponent implements OnInit {

    tabNavegarNuevos = false;
    tabNavegarTodos = false;

  constructor(public router: Router) { }

  ngOnInit(): void {
  }

    initClickNuevos() {
        this.navegarRecomendadoNuevos();
    }

    initClickTodos() {
        this.navegarRecomendadoTodos();
    }

    initClickEvaluacion() {
        this.navegarRecomendadoEvaluacion();
    }

    initClickContratados() {
        this.navegarRecomendadoContratados();
    }

    navegarRecomendadoNuevos() {
        this.router.navigate([ConstantesUtil.paginaNuevos]);
    }

    navegarRecomendadoTodos() {
        this.router.navigate([ConstantesUtil.paginaTodos]);
    }

    navegarRecomendadoEvaluacion() {
        this.router.navigate([ConstantesUtil.paginaEvaluacion]);
    }

    navegarRecomendadoContratados() {
        this.router.navigate([ConstantesUtil.paginaContratados]);
    }

}
