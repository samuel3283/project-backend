export class Estado {

    id: string;

}
