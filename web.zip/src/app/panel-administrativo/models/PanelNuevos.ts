export class PanelNuevos {

}

