export class ParametroEnvioContratado {
    estado: string[];
    idPuesto: number[];
    idReclutador: number[];
    marca: string[];
    grupo: string[];
    fechaInicio: string;
    fechaFin: string;
    nombreRecomendado: string;
    idTipoBusqueda = 2;
    fechaRegistro: string[];

    constructor(estado: string[], idPuesto: number[], idReclutador: number[], marca: string[], grupo: string[], nombreRecomendado:  string,
                fechaInicio: string, fechaFin: string, fechaRegistro: string[]) {
        this.estado = estado;
        this.idPuesto = idPuesto;
        this.idReclutador = idReclutador;
        this.nombreRecomendado = nombreRecomendado;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.fechaRegistro = fechaRegistro;
        this.marca = marca;
        this.grupo = grupo;
    }
}



