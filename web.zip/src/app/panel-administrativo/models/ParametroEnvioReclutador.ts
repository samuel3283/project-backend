export class ParametroEnvioReclutador {
        nombre: string;
        id: string;

    constructor(nombre: string, id: string) {
        this.nombre = nombre;
        this.id = id;
    }
}



