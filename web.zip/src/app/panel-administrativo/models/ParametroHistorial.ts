export class ParametroHistorial {
        documento: string;
        idTipoBusqueda = 1;

        constructor(documento: string) {
                this.documento = documento;
        }
}



