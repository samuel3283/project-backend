export class ParametroReclutador {
        idPuesto: string;
        idTipoBusqueda = 1;

        constructor(idPuesto: string) {
                this.idPuesto = idPuesto;
        }
}



