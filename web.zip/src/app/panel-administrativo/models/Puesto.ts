export class Puesto{
    id: number;
}
