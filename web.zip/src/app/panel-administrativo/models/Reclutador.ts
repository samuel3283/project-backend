export class Reclutador {
    id?: number;
    nombreReclutador?: string;
    correo?: string;

    constructor(id: number, nombreReclutador: string, correo: string) {
        this.id = id;
        this.nombreReclutador = nombreReclutador;
        this.correo = correo;
    }
}
