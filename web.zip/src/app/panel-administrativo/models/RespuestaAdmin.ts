export class RespuestaAdmin {
    idOpcionRespuesta: string;
    idPregunta: string;
    respuestaEnunciado: string;
    respuestaAutocomplete: string;
}
