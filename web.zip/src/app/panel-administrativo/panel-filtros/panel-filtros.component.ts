import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-panel-filtros',
  templateUrl: './panel-filtros.component.html',
  styleUrls: ['./panel-filtros.component.scss']
})
export class PanelFiltrosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
