import { Component, OnInit } from '@angular/core';
import {PanelService} from '../services/panel.service';
import {ActivatedRoute, Router} from '@angular/router';
import {ReclutadorService} from '../services/reclutador.service';
import {ParametroReclutador} from '../models/ParametroReclutador';
import {Reclutador} from '../models/Reclutador';
import {ParametroEnvioReclutador} from '../models/ParametroEnvioReclutador';

@Component({
  selector: 'app-reclutadores',
    templateUrl: './reclutadores.component.html',
    styleUrls: ['./reclutadores.component.scss']
})
export class ReclutadoresComponent implements OnInit {

    reclutador: ParametroEnvioReclutador;
    reclutadorSeleccionado: Reclutador;
    errores: string[];
    tecnicos: any[];
    quimicos: any[];
    data: any;
    paginadorTodos: any;
    loading = true;
    parametrosRequest: ParametroEnvioReclutador;
    parametrosRequestReclutadorTF: ParametroReclutador;
    parametrosRequestReclutadorQ: ParametroReclutador;
    clonedProducts: { [s: string]: Reclutador; } = {};

  constructor(private panelService: PanelService,
              private router: Router,
              private activatedRoute: ActivatedRoute,
              private reclutadorService: ReclutadorService) { }

  ngOnInit(): void {
          this.parametrosRequest =  new ParametroEnvioReclutador('', '');
          this.parametrosRequestReclutadorTF = new ParametroReclutador('2');
          this.parametrosRequestReclutadorQ = new ParametroReclutador('1');

          this.getReclutadorTF();
          this.getReclutadorQ();

  }

    public getReclutadorTF() {
        console.log(this.parametrosRequestReclutadorTF);
        this.reclutadorService.getReclutadoresPuesto( this.parametrosRequestReclutadorTF).subscribe(data => {
            console.log(data);
            this.tecnicos = data['source'];
            this.paginadorTodos = data;
        });
    }
    public getReclutadorQ() {
        console.log(this.parametrosRequestReclutadorQ);
        this.reclutadorService.getReclutadoresPuesto( this.parametrosRequestReclutadorQ).subscribe(data => {
            console.log(data);
            this.quimicos = data['source'];
            this.paginadorTodos = data;
        });
    }



    update(id: any) {
        console.log(this.parametrosRequest);
        this.reclutadorService.updateReclutador(this.parametrosRequest)
            .subscribe(
                json => {
                    this.router.navigate(['/admin/panel/reclutadores']);
                },
                err => {
                    this.errores = err.error.errors as string[];
                    console.error('Código del error desde el backend: ' + err.status);
                    console.error(err.error.errors);
                }
            );
        window.location.reload();
    }

    onRowEditInit(product: Reclutador) {
        this.clonedProducts[product.id] = {...product};
    }

    onRowEditSave(product: Reclutador) {
        this.reclutadorService.updateReclutador(product)
            .subscribe(
                json => {
                    this.router.navigate(['/admin/panel/reclutadores']);
                },
                err => {
                    this.errores = err.error.errors as string[];
                    console.error('Código del error desde el backend: ' + err.status);
                    console.error(err.error.errors);
                }
            );
        setTimeout(function() { location.reload(); }, 2000);
    }

    onRowEditCancel(product: Reclutador, index: number) {
        this.data[index] = this.clonedProducts[product.id];
        delete this.data[product.id];
    }

}
