import {Injectable} from '@angular/core';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class LocalService {
    theUrl = environment.ws + '/local';

    constructor(private http: HttpClient) {
    }

    public obtenerListaLocalesPorNombre(term: string): Observable<any> {
        return this.http.get<any>(this.theUrl + '/' + term);
    }

    public obtenerLocalId(idLocal: any): Observable<any> {
        return this.http.get<any>(this.theUrl + '/obtenerLocal/' + idLocal);
    }

}
