import { Injectable } from '@angular/core';
import {environment} from '../../../environments/environment';
import {HttpClient} from '@angular/common/http';
import {PanelNuevos} from '../models/PanelNuevos';
import {Observable, throwError} from 'rxjs';
import {ParametroEnvio} from '../models/ParametroEnvio';

@Injectable({
  providedIn: 'root'
})
export class PanelService {

  theUrl: any = environment.ws;
    parametro = ParametroEnvio['postData'];
  constructor(public http: HttpClient) { }

    postData = {
        "estado": ['nuevo'],
        "idPuesto": [],
        "idReclutador": [],
        "fechaInicio": '2020-07-04',
        "fechaFin": '2020-07-04',
        "nombreRecomendado": '',
        "idTipoBusqueda": 1
    };
    url = `http://localhost:8080/api/v1/recomendados/list`;


    getEstados() {
        return this.http.get(`${this.theUrl}/parametro/empresa/Estado`);
    }
    getGrupos() {
        return this.http.get(`${this.theUrl}/grupos/`);
    }
    getMarcas() {
        return this.http.get(`${this.theUrl}/parametro/empresa/Filtro`);
    }

    public getRecomendados(): Observable<PanelNuevos> {
        return this.http.get<PanelNuevos>(`${this.theUrl}/recomendados/panelNuevo`);
    }

    public getRecomendadosNuevos(): Observable<PanelNuevos> {
        return this.http.get<PanelNuevos>(`${this.theUrl}/recomendados/panelNuevo`);
    }

    public getRecomendadosNuevosPuesto(puesto: string): Observable<PanelNuevos> {
        return this.http.get<PanelNuevos>(`${this.theUrl}/recomendados/panelNuevo/puesto/` + puesto);
    }

    public getNuevos(request: any) {
      return this.http.post(`${this.theUrl}/recomendados/list`, request);
    }

}
