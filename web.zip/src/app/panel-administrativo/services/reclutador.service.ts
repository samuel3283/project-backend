import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import { TreeNode } from 'primeng/api';
import { throwError} from 'rxjs';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReclutadorService {

  url: any = `${environment.ws}/reclutadores`;
  url2: any = `${environment.ws}/grupos`;

  constructor(private http: HttpClient) { }

    getReclutadores() {
        return this.http.get(`${this.url2}/reclutadores`);
    }


    public getReclutadoresPuesto(request: any) {
        return this.http.post(`${this.url}/puesto?size=10`, request);
    }

    public updateReclutador(request: any){
        return this.http.put(`${this.url}/actualizarReclutador`, request).pipe(
            catchError(e => {
                if (e.status == 400) {
                    return throwError(e);
                }
                if (e.error.mensaje) {
                    console.error(e.error.mensaje);
                }
                return throwError(e);
            }));
    }
}
