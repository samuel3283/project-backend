import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
    selector: 'app-paginator-todos',
    templateUrl: './paginator-todos.component.html'
})
export class PaginatorTodosComponent implements OnInit, OnChanges {

    @Input() paginadorTodos: any;

    paginas: number[];

    desde: number;
    hasta: number;

    constructor() { }

    ngOnInit() {
        this.initPaginator();
    }

    ngOnChanges(changes: SimpleChanges) {
        const paginadorActualizado = changes['paginadorTodos'];

        if (paginadorActualizado.previousValue) {
            this.initPaginator();
        }

    }

    private initPaginator(): void {
        this.desde = Math.min(Math.max(1, this.paginadorTodos.number - 4), this.paginadorTodos.pageCount - 5);
        this.hasta = Math.max(Math.min(this.paginadorTodos.pageCount, this.paginadorTodos.number + 4), 6);

        if (this.paginadorTodos.totalPages > 5) {
            this.paginas = new Array(this.hasta - this.desde + 1).fill(0).map((_valor, indice) => indice + this.desde);
        } else {
            this.paginas = new Array(this.paginadorTodos.pageCount).fill(0).map((_valor, indice) => indice + 1);
        }
    }

}
