import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../../environments/environment';


@Injectable({
    providedIn: 'root'
})
export class CvService {

    theUrl = environment.ws;

    constructor(public http: HttpClient) {
    }


    public subirArchivoTemporal(file: File) {
        const formData: FormData = new FormData();
        formData.append('file', file);

        return this.http.post<any>(this.theUrl + '/cv/subirArchivoTemporal/', formData);
    }

    /* public actualizarCv(file: File, recomendacion: any) {
       const formData: FormData = new FormData();
       formData.append('fileFirmaDigital', file);
       formData.append('recomendacion', JSON.stringify(recomendacion));
       return this.http.post<any>(this.theUrl + '/cv/actualizarCv', formData);
     }*/


    public descargarArchivo(imagen: any): Observable<any> {
        return this.http.get<any>(this.theUrl + '/cv/descargarArchivo/' + imagen);
    }


    public mostrarCv(imagen: any) {
        window.open(this.theUrl + '/cv/descargarArchivo/' + imagen, '_blank');
    }


    public actualizarCv(archivo: File) {
        const sesionIdRecomendado = sessionStorage.getItem('idRecomendado');
        const formData: FormData = new FormData();
        formData.append('archivo', archivo);
        formData.append('id', sesionIdRecomendado);
        return this.http.post<any>(this.theUrl + '/cv/subirCV', formData);
    }

    public actualizarCvAdmin(archivo: File, idRecomendado: any) {
        const formData: FormData = new FormData();
        formData.append('archivo', archivo);
        formData.append('id', idRecomendado);
        return this.http.post<any>(this.theUrl + '/cv/subirCV', formData);
    }


}
