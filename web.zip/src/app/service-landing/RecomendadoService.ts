import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
import {environment} from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class RecomendadoService {

    theUrl = environment.ws;

    constructor(public http: HttpClient) {
    }

    public obtenerRecomendadoPorDni(numeroDni: string): Observable<any> {
        return this.http.get<any>(this.theUrl + '/recomendados/documento/' + numeroDni);
    }

    public crearRecomendados(recomendados: any): Observable<any> {
        return this.http.post<any>(this.theUrl + '/recomendados/crearRecomendados', recomendados);
    }

    public getRecomendados() {
        return this.http.get<any>(`${this.theUrl}/recomendados`);
    }

    public obtenerRecomendadoPorId(idRecomendado: any, idRecomendacion: any): Observable<any> {
        return this.http.get<any>(this.theUrl + '/recomendados/dataGlobalRecomendado/' + idRecomendado + '/' + idRecomendacion);
        //return this.http.get<any>(this.theUrl + '/recomendados/dataGlobalRecomendado/' + 637 + '/' + 609);
    }

    public actualizarEstadoRecomendado(recomendado: any): Observable<any> {
        return this.http.put<any>(this.theUrl + '/recomendados/actualizarEstado/', recomendado);
    }

    public actualizarRecomendado(recomendado: any): Observable<any> {
        return this.http.put<any>(this.theUrl + '/recomendados/actualizarRecomendado/', recomendado);
    }

    public getHistorial(request: any) {
        return this.http.post(`${this.theUrl}/recomendacion/historial`, request);
    }
}
