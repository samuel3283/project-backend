import {Injectable} from '@angular/core';

import {environment} from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class SesionService {

    constructor() {
    }

    public validarExistenciaToken(): boolean {
        const token = sessionStorage.getItem('token');

        if (token === null || token === '' || token === undefined) {
            sessionStorage.clear();
            location.href = environment.urlPortal;

            return false;
        }

        return true;
    }

}

