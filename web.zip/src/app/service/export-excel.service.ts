import { Injectable } from '@angular/core';
import { Workbook } from 'exceljs';
import * as fs from 'file-saver';
import * as logo from './mylogo.js';

@Injectable({
    providedIn: 'root'
})
export class ExportExcelService {


    constructor() { }

    exportExcel(excelData) {

        // Title, Header & Data
        const title = excelData.title;
        const header = excelData.headers;
        const data = excelData.data;

        // Crea un libro de trabajo con una hoja de trabajo
        let workbook = new Workbook();
        let worksheet = workbook.addWorksheet('Lista de recomendados');

        // Agregar fila y formato
        worksheet.mergeCells('L1', 'O4');
        let titleRow = worksheet.getCell('L1');
        titleRow.value = title;
        titleRow.font = {
            name: 'Calibri',
            size: 16,
            underline: 'single',
            bold: true,
            color: { argb: '0085A3' }
        };
        titleRow.alignment = { vertical: 'middle', horizontal: 'center' };

        // Date
        worksheet.mergeCells('P1:Q4');
        let d = new Date();
        let date = d.getDate() + '-' + d.getMonth() + '-' + d.getFullYear();
        let dateCell = worksheet.getCell('P1');
        dateCell.value = date;
        dateCell.font = {
            name: 'Calibri',
            size: 12,
            bold: true
        };
        dateCell.alignment = { vertical: 'middle', horizontal: 'center' };

        // Add Image
        let myLogoImage = workbook.addImage({
            base64: logo.imgBase64,
            extension: 'png',
        });
        worksheet.mergeCells('I1:K4');
        worksheet.addImage(myLogoImage, 'I1:K4');

        // Blank Row
        worksheet.addRow([]);

        // Agregar Header Row
        let headerRow = worksheet.addRow(header);
        headerRow.eachCell((cell, number) => {
            cell.fill = {
                type: 'pattern',
                pattern: 'solid',
                fgColor: { argb: '4167B8' },
                bgColor: { argb: '' }
            };
            cell.font = {
                bold: true,
                color: { argb: 'FFFFFF' },
                size: 12
            };
        });

        // Agregar datos con formato condicional
        data.forEach( d => {
                const row = worksheet.addRow(d);
                const sales = row;

            row.width = 15;
                sales.fill = {
                    type: 'pattern',
                    pattern: 'none'
                };
                sales.alignment = {
                    horizontal: 'center',
                    vertical: 'center'
                };
            }
        );

        worksheet.getColumn(3).width = 20;
        worksheet.addRow([]);

        // Footer Row
        let footerRow = worksheet.addRow(['Reporte de Recomendados Generado por el equipo Talento ' + date]);
        footerRow.getCell(1).fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FFB050' }
        };

        // Combinar celdas
        worksheet.mergeCells(`A${footerRow.number}:F${footerRow.number}`);

        // Generar y guardar archivo de Excel
        workbook.xlsx.writeBuffer().then((data) => {
            let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
            fs.saveAs(blob, title + '.xlsx');
        });

    }
}
