import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

import {environment} from '../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class LoginService {

    theUrl = environment.ws;

    constructor(public http: HttpClient) {
    }

    public loginPortal(token: any): Observable<any> {
        return this.http.get<any>(this.theUrl + '/login/loginPortal/' + token);
    }

    public divisionNumeros(): Observable<any> {
        return this.http.get<any>('http://localhost:8080/api/v1/spring/divisionNumeros/10/0');
    }

}
