import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { AppTopBarComponent } from './header/app.topbar.component';
import { AppFooterComponent } from './footer/app.footer.component';
@NgModule({
    imports: [
    ],
    declarations: [
        AppTopBarComponent,
        AppFooterComponent
    ],
    exports: [
        AppTopBarComponent,
        AppFooterComponent
    ],
    schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class SharedModule { }
