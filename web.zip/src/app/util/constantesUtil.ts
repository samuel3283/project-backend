export class ConstantesUtil {

    public static talento = 'talento';

    /*Roles usuario*/
    public static ROL_USUARIO_ADMIN = 'admin';

    /*Tipos Paginas*/
    public static paginaReclutadores = 'admin/panel/reclutadores';

    public static paginaAdministrativo = 'admin/panel/nuevos';
    public static paginaEditar = 'admin/panel/editar/recomendado';
    public static paginaTodos = 'admin/panel/todos';
    public static paginaNuevos = 'admin/panel/nuevos';
    public static paginaEvaluacion = 'admin/panel/evaluacion';
    public static paginaContratados = 'admin/panel/contratados';
    /*Response*/
    public static codMsjOk = '100';
    public static codMsjNotValid = '101';
    public static codMsjError = '000';
    /*Tipos Estado*/
    public static tipo_estado_contratado = 'Contratado';
    public static tipo_estado_en_proceso_contratacion = 'En proceso de contratación';
    public static tipo_estado_en_espera = 'En espera';
    public static tipo_estado_rechazado = 'Rechazado';
    public static tipo_estado_derivado = 'Derivado';

    /*Modulo */
    public static moduloLanding = 'modulo_landing';
    /*Tipo Parametro */
    public static parametroTipoFamiliarRelacion = 'RELACION';
    public static parametroTipoEstado = 'Estado';
    public static parametroTiempoPeriodo = 'PERIODO';
    public static parametroTipoEmpresa = 'EMPRESA';
    public static parametroTipoHorario = 'HORARIO';
    public static parametroTipoEnEspera = 'ESTADO_ESPERA';
    public static parametroTipoRechazado = 'ESTADO_RECHAZADO';
    /*Tipo Pregunta */
    public static tipo_pregunta_radio_button = '1';
    public static tipo_pregunta_auto_complete = '2';


    public static validarEstado(): any {
        let date;
        date = {
            firstDayOfWeek: 1,
            dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
            dayNamesShort: ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'],
            dayNamesMin: ['D', 'L', 'M', 'X', 'J', 'V', 'S'],
            monthNames: ['Enero', 'Eebrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'],
            monthNamesShort: ['Ene', 'Deb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'],
            today: 'Hoy',
            clear: 'Borrar'
        };
        return date;
    }

}
