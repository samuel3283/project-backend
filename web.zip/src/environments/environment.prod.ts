export const environment = {
    production: true,
    //  ws: 'https://capexws.farmaciasperuanas.pe/api/v1',
    ws: '/api/v1',
    //urlPortal : 'http://portal.farmaciasperuanas.pe',
    urlPortal: ' http://dev.portalfarmaciasweb.solucionesfps.pe/portal',
    urlWSPortal: 'https://accountws.farmaciasperuanas.pe',
    urlDefaultTalento: 'https://recomiendauntalento.pe/talento/landing',
    nameAppIcapexPortal: 'Talento-App'
};
