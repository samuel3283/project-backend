export const environment = {
	production: false,
	ws: 'http://qa.talento.solucionesfps.pe/api/v1',
	urlPortal : 'http://dev.portalfarmaciasweb.solucionesfps.pe',
	urlWSPortal : 'http://dev.projectmanagerws.solucionesfps.pe',
    urlDefaultTalento: 'http://dev.talento.solucionesfps.pe/',
	nameAppIcapexPortal : 'Talento-DEV'
};
