export const environment = {
    production: false,
    ws: 'http://dev.talento.solucionesfps.pe/api/v1',
    // ws: 'http://localhost:8080/api/v1',
    urlPortal: 'http://dev.portalfarmaciasweb.solucionesfps.pe/portal',
    urlWSPortal: 'http://dev.projectmanagerws.solucionesfps.pe',
    urlDefaultTalento: 'http://dev.talento.solucionesfps.pe/',
    nameAppIcapexPortal: 'Talento-DEV'
};
